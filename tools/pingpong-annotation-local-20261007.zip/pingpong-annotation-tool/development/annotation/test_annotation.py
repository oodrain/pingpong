"""Meaningful regression checks; all synthetic records stay in temporary directories."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import cv2
import numpy as np

from annotation_core import (SELF_CHECK_DELAY, OutputLock, Session, Transform, compare_events,
                             prepare, read_json, write_image, write_json)
from annotate import Viewer


def state():
    return {"schema_version": 1, "inputs": {}, "video": {"video_id": "test", "width": 1920,
            "height": 1080, "n_frames": 3, "fps": 25}, "current_round": "initial",
            "rounds": {r: {"current_frame": 0, "seen_frames": [], "reviewed_frames": [],
            "completed_at": None, "window_seconds": 0.0, "no_events_reason": ""}
            for r in ("initial", "selfcheck")}, "events": {"initial": [], "selfcheck": []},
            "uncertain": [], "timing": {"decode_seconds": 0}}


class AnnotationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.output = Path(self.directory.name)
        self.session = Session(self.output, state())

    def test_full_scaled_and_zoom_coordinate_roundtrip(self):
        for transform in (Transform(0, 0, 1920, 1080, 0, 0, 1920, 1080),
                          Transform(0, 96, 1000, 562, 0, 0, 1920, 1080),
                          Transform(0, 0, 480, 480, 374, 447, 96, 96)):
            original = (422.37, 495.40)
            display = transform.to_display(*original)
            restored = transform.to_original(*(round(v) for v in display))
            self.assertLessEqual(max(abs(a-b) for a, b in zip(original, restored)), 1)
        self.assertIsNone(Transform(0, 95, 1000, 562, 0, 0, 1920, 1080).to_original(10, 94))

    def test_duplicate_update_bounds_and_nan(self):
        self.session.put_event(1, 100, 200)
        self.session.put_event(1, 110, 220)
        self.assertEqual(len(self.session.events), 1)
        self.assertEqual(self.session.events[0]["x"], 110)
        for f, x, y in ((3, 0, 0), (-1, 0, 0), (1, -1, 0), (1, 1920, 0),
                        (1, 0, 1080), (1, float("nan"), 0)):
            with self.assertRaises(ValueError):
                self.session.put_event(f, x, y)

    def test_output_lock_prevents_overwrite_and_releases(self):
        with OutputLock(self.output):
            with self.assertRaises(ValueError):
                with OutputLock(self.output):
                    pass
        with OutputLock(self.output):
            pass

    def test_keypress_save_list_delete_and_uncertain(self):
        (self.output / "frames").mkdir()
        for f in range(3):
            write_image(self.output / "frames" / f"{f:06d}.png",
                        np.zeros((1080, 1920, 3), np.uint8))
        viewer = Viewer(self.session, {"frames": []})
        viewer.render()
        viewer.mouse(cv2.EVENT_LBUTTONDOWN, 100, 200, 0, None)
        viewer.handle_key(13)
        self.assertEqual(len(self.session.events), 1)
        viewer.mouse(cv2.EVENT_LBUTTONDOWN, 110, 210, 0, None)
        viewer.handle_key(13)
        self.assertEqual(len(self.session.events), 1)
        viewer.handle_key(ord("i"))
        viewer.handle_key(ord("d"))
        viewer.handle_key(ord("o"))
        with patch.object(viewer, "dialog", return_value="球被遮挡"):
            viewer.handle_key(ord("u"))
        self.assertEqual(len(self.session.state["uncertain"]), 1)
        viewer.render()
        top, bottom, event_id, target = viewer.rows[0]
        viewer.mouse(cv2.EVENT_LBUTTONDOWN, 1050, (top+bottom)//2, 0, None)
        self.assertEqual(viewer.selected, event_id)
        viewer.handle_key(3014656)  # Windows Delete
        self.assertEqual(self.session.events, [])
        self.assertEqual(len(self.session.state["uncertain"]), 1)
        viewer.handle_key(ord("a"))
        self.assertEqual(viewer.frame, 0)
        viewer.handle_key(ord("v"))
        viewer.handle_key(ord("v"))
        viewer.handle_key(ord("v"))
        self.assertEqual(viewer.frame, 2)
        with patch.object(viewer, "dialog", return_value="本轮只有疑难区间"), patch.object(viewer, "confirm", return_value=True):
            viewer.handle_key(ord("c"))
        self.assertIsNotNone(self.session.progress["completed_at"])
        restored = Session(self.output, read_json(self.output / "session.json"))
        self.assertEqual(restored.state, self.session.state)

    def test_uncertainty_validation_update_and_delete(self):
        for start, end, reason in ((2, 1, "occluded"), (0, 3, "occluded"), (0, 1, " ")):
            with self.assertRaises(ValueError):
                self.session.put_uncertain(start, end, reason)
        record = self.session.put_uncertain(0, 1, "遮挡")
        self.session.put_uncertain(0, 1, "两帧之间")
        self.assertEqual(len(self.session.state["uncertain"]), 1)
        self.session.delete(record["event_id"])
        self.assertEqual(self.session.state["uncertain"], [])

    def test_canonical_restore_and_partial_report(self):
        self.session.put_event(1, 100, 200)
        self.session.put_uncertain(0, 1, "遮挡")
        self.session.set_frame(2)
        self.session.mark_reviewed()
        self.session.save()
        (self.output / "events_initial.jsonl").write_text("interrupted export", encoding="utf-8")
        restored = Session(self.output, read_json(self.output / "session.json"))
        restored.save()
        self.assertEqual(restored.state, self.session.state)
        self.assertEqual(json.loads((self.output / "events_initial.jsonl").read_text("utf-8"))["x"], 100)
        self.assertIn("试点未完成", (self.output / "pilot_report.md").read_text("utf-8"))

    def test_playback_seen_is_not_reviewed(self):
        for f in range(3):
            self.session.set_frame(f)
            self.session.mark_seen()
        with self.assertRaises(ValueError):
            self.session.complete("没有确定事件", now=1000)
        for f in range(3):
            self.session.set_frame(f)
            self.session.mark_reviewed()
        with self.assertRaises(ValueError):
            self.session.complete(now=1000)
        self.session.complete("仅疑难，没有确定事件", now=1000)
        self.assertEqual(self.session.progress["completed_at"], 1000)

    def test_selfcheck_gap_freeze_and_independence(self):
        with self.assertRaises(ValueError):
            self.session.switch_round("selfcheck", now=1000)
        self.session.put_event(1, 100, 200)
        self.session.progress["reviewed_frames"] = [0, 1, 2]
        self.session.progress["seen_frames"] = [0, 1, 2]
        self.session.complete(now=1000)
        with self.assertRaises(ValueError):
            self.session.put_event(1, 120, 220)
        with self.assertRaises(ValueError):
            self.session.delete(self.session.events[0]["event_id"])
        self.session.switch_round("selfcheck", now=1000)
        self.assertEqual(SELF_CHECK_DELAY, 0)
        self.assertEqual(self.session.events, [])
        viewer = Viewer.__new__(Viewer)
        viewer.session = self.session
        self.assertEqual(viewer.visible_records(), [])
        self.session.put_event(1, 115, 210)
        self.assertEqual(self.session.state["events"]["initial"][0]["x"], 100)

    def test_maximum_one_to_one_matching_and_boundaries(self):
        def event(name, frame, x, y=100):
            return {"event_id": name, "frame_id": frame, "x": x, "y": y}
        first = [event("i0", 1, 100), event("i1", 1, 180)]
        second = [event("s0", 1, 140), event("s1", 1, 50)]
        result = compare_events(first, second)
        self.assertEqual(len(result["matches"]), 2)  # nearest-first greedy gets only one
        result = compare_events([event("i", 0, 100)], [event("s", 1, 150)])
        self.assertEqual(len(result["matches"]), 1)
        result = compare_events([event("i", 0, 100)], [event("s", 2, 150)])
        self.assertEqual(len(result["matches"]), 0)
        result = compare_events([event("i", 0, 100)], [event("s", 0, 150.01)])
        self.assertEqual(len(result["matches"]), 0)
        result = compare_events(first, [event("s", 1, 140)])
        self.assertEqual(len(result["matches"]), 1)
        self.assertEqual(len(result["initial_only"]), 1)

    def test_full_completed_report(self):
        for r in ("initial", "selfcheck"):
            if r == "selfcheck":
                self.session.switch_round(r, now=2200)
            for f in range(3):
                self.session.set_frame(f)
                self.session.mark_reviewed()
            self.session.put_event(1, 100, 200)
            self.session.complete(now=1000 if r == "initial" else 3000)
        self.session.save()
        self.assertIn("两遍查看完成", (self.output / "pilot_report.md").read_text("utf-8"))
        self.assertEqual(len(read_json(self.output / "comparison.json")["matches"]), 1)

    def test_sequential_decode_mismatch_pauses_before_session(self):
        class Capture:
            index = 0
            def isOpened(self): return True
            def getBackendName(self): return "test"
            def get(self, prop): return 25 if prop == cv2.CAP_PROP_FPS else 2
            def read(self):
                self.index += 1
                return (True, np.zeros((16, 32, 3), np.uint8)) if self.index <= 2 else (False, None)
            def release(self): pass
        video, annotation = self.output / "video.mp4", self.output / "annotation.json"
        video.write_bytes(b"synthetic-video")
        declared = {"video_id": "test", "num_frames": 3, "frame_width": 32,
                    "frame_height": 16, "frames": [{"frame_id": i} for i in range(3)]}
        write_json(annotation, declared)
        with patch("annotation_core.cv2.VideoCapture", return_value=Capture()):
            with self.assertRaises(ValueError):
                prepare(video, annotation, self.output / "run")
        validation = read_json(self.output / "run/decode_validation.json")
        self.assertFalse(validation["ok"])
        self.assertFalse((self.output / "run/session.json").exists())

    def test_actual_frames_navigation_missing_box_and_render(self):
        # Read-only real-data check. UI preview must not count as a human review.
        root = Path(__file__).resolve().parents[2]
        source = root / "outputs/annotation_pilot/03_007"
        if not (source / "session.json").exists():
            self.skipTest("prepare real video first")
        real = read_json(source / "session.json")
        session = Session(source, copy.deepcopy(real))
        annotation = read_json(root / "examples/training/03_007/annotation.json")
        viewer = Viewer(session, annotation, tracking=False)
        before = copy.deepcopy(session.state)
        for f in (0, 116, 8, 0):
            viewer.load_frame(f)
            self.assertEqual(viewer.frame, f)
            self.assertEqual(viewer.render().shape, (814, 1360, 3))
        viewer.load_frame(8)
        self.assertEqual(viewer.boxes(8), [])
        self.assertEqual(session.state, before)
        viewer.render()
        viewer.mouse(cv2.EVENT_LBUTTONDOWN, 100, 200, 0, None)
        x, y = viewer.pending
        self.assertTrue(0 <= x < 1920 and 0 <= y < 1080)
        viewer.zoom_image()
        viewer.zoom_mouse(cv2.EVENT_LBUTTONDOWN, 240, 240, 0, None)
        self.assertIsNotNone(viewer.pending)


if __name__ == "__main__":
    unittest.main()
