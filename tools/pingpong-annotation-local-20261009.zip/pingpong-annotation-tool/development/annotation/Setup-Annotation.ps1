param(
    [string]$PythonPath = '',
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$taskVenv = Join-Path $taskRoot '.venv-annotation'
$taskPython = Join-Path $taskVenv 'Scripts\python.exe'
$taskRequirements = Join-Path $PSScriptRoot 'requirements-lock.txt'
$taskCheck = Join-Path $PSScriptRoot 'check_environment.py'

try {
    if (-not (Test-Path -LiteralPath $taskPython)) {
        if ($CheckOnly) { throw 'Environment missing. Install 64-bit Python 3.12, then run the installer.' }
        $taskBasePython = $null
        $taskVersionCheck = 'import sys,struct; print(sys.executable if sys.version_info[:2] == (3,12) and struct.calcsize("P") == 8 else "")'
        if ($PythonPath) {
            $taskCandidate = (Resolve-Path -LiteralPath $PythonPath).Path
            $taskFound = & $taskCandidate -c $taskVersionCheck
            if ($LASTEXITCODE -eq 0 -and $taskFound) { $taskBasePython = [string]$taskFound }
        } else {
            $taskLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
            if ($taskLauncher) {
                $taskFound = & $taskLauncher.Source -3.12 -c $taskVersionCheck 2>$null
                if ($LASTEXITCODE -eq 0 -and $taskFound) { $taskBasePython = [string]$taskFound }
            }
            if (-not $taskBasePython) {
                $taskCommand = Get-Command python.exe -ErrorAction SilentlyContinue
                if ($taskCommand) {
                    $taskFound = & $taskCommand.Source -c $taskVersionCheck 2>$null
                    if ($LASTEXITCODE -eq 0 -and $taskFound) { $taskBasePython = [string]$taskFound }
                }
            }
        }
        if (-not $taskBasePython) { throw '64-bit Python 3.12 not found. Install it first, or pass -PythonPath.' }
        Write-Host 'Creating a local annotation environment...'
        & $taskBasePython -m venv $taskVenv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the virtual environment.' }
    }

    & $taskPython $taskCheck
    if ($LASTEXITCODE -eq 0) {
        Write-Host 'Annotation environment is ready. Double-click the launcher to import local files.'
        exit 0
    }
    if ($CheckOnly) { exit 1 }
    $taskVersion = & $taskPython -c 'import sys,struct; print("OK" if sys.version_info[:2] == (3,12) and struct.calcsize("P") == 8 else "WRONG")'
    if ($LASTEXITCODE -ne 0 -or $taskVersion -ne 'OK') {
        throw 'Existing environment is not Python 3.12 x64. Keep labels, rename .venv-annotation, then rerun.'
    }
    Write-Host 'Installing locked GUI dependencies. Internet access is needed for this step...'
    & $taskPython -m pip install --only-binary=:all: --disable-pip-version-check -r $taskRequirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency download/install failed. Check the network and rerun; labels are untouched.' }
    & $taskPython $taskCheck
    if ($LASTEXITCODE -ne 0) { throw 'Environment check failed. Send the console message to the group leader.' }
    Write-Host 'Setup complete. Double-click the annotation launcher to start.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
