import json
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from adjudication import AdjudicationProject, AdjudicationViewer, ReviewTransform


class AdjudicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.package = self.root / "package"
        self.data = self.root / "data"
        self.package.mkdir()
        pairs = [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A")] * 4
        self.cases = []
        for index, (initial, reviewer) in enumerate(pairs):
            video_id = f"{index:02d}_001"
            case = {
                "case_id": f"{initial}-{reviewer}_{video_id}_01",
                "video_id": video_id,
                "initial_annotator": initial,
                "reviewer": reviewer,
                "frame_start": 10,
                "frame_end": 20,
                "initial_only_events": [],
                "review_only_events": [],
                "initial_uncertain": [],
                "review_uncertain": [],
            }
            self.cases.append(case)
            scene, clip = video_id.split("_")
            (self.data / initial / "videos" / scene).mkdir(parents=True, exist_ok=True)
            (self.data / initial / "json" / scene).mkdir(parents=True, exist_ok=True)
            (self.data / initial / "videos" / scene / f"{clip}.mp4").write_bytes(b"video")
            (self.data / initial / "json" / scene / f"{clip}.json").write_text("{}", encoding="utf-8")
        self.template = self.package / "decision_template.jsonl"
        self.template.write_text("".join(json.dumps(row) + "\n" for row in self.cases), encoding="utf-8")
        self.project = AdjudicationProject(self.package, self.data)

    def test_assignment_is_balanced_and_excludes_both_prior_annotators(self):
        loads = {member: len(self.project.cases_for(member)) for member in "ABCD"}
        self.assertLessEqual(max(loads.values()) - min(loads.values()), 1)
        for case in self.cases:
            self.assertNotIn(self.project.assigned_to(case), {case["initial_annotator"], case["reviewer"]})

    def test_save_is_separate_and_does_not_modify_template(self):
        original = self.template.read_bytes()
        case = self.cases[0]
        member = self.project.assigned_to(case)
        result = self.project.save_decision(member, case, "confirmed", 15, 12.5, 8.25)
        self.assertEqual(result["decision"], "confirmed")
        self.assertTrue(result["blind_review"])
        self.assertFalse(result["completed"])
        self.assertEqual(self.project.status(member, case), "in_progress")
        self.assertEqual(self.template.read_bytes(), original)
        saved = self.project.decisions_for(member)[case["case_id"]]
        self.assertEqual(saved["final_frame_id"], 15)
        self.assertTrue(self.project.decision_path(member).is_file())
        completed = self.project.complete_decision(member, case)
        self.assertTrue(completed["completed"])
        self.assertEqual(self.project.status(member, case), "confirmed")
        self.assertEqual(self.template.read_bytes(), original)

    def test_validation_for_confirmed_uncertain_and_wrong_reviewer(self):
        case = self.cases[0]
        member = self.project.assigned_to(case)
        with self.assertRaisesRegex(ValueError, "帧号和球心"):
            self.project.save_decision(member, case, "confirmed")
        with self.assertRaisesRegex(ValueError, "范围"):
            self.project.save_decision(member, case, "confirmed", 30, 1, 2)
        with self.assertRaisesRegex(ValueError, "原因"):
            self.project.save_decision(member, case, "uncertain")
        with self.assertRaisesRegex(ValueError, "未分配"):
            self.project.save_decision(case["initial_annotator"], case, "no_bounce")

    def test_completed_decision_can_be_reopened_with_audited_reason(self):
        original = self.template.read_bytes()
        case = self.cases[0]
        member = self.project.assigned_to(case)
        self.project.save_decision(member, case, "confirmed", 15, 12.5, 8.25)
        self.project.complete_decision(member, case)
        with self.assertRaisesRegex(ValueError, "原因"):
            self.project.reopen_decision(member, case, "")
        reopened = self.project.reopen_decision(member, case, "球心点偏，重新校正")
        self.assertFalse(reopened["completed"])
        self.assertEqual(reopened["edit_count"], 1)
        self.assertEqual(reopened["last_edit_reason"], "球心点偏，重新校正")
        self.assertEqual(self.project.status(member, case), "in_progress")
        history = list((self.package / "third_review" / "history").glob("*.json"))
        self.assertEqual(len(history), 1)
        self.assertTrue(json.loads(history[0].read_text(encoding="utf-8"))["completed"])
        self.project.save_decision(member, case, "confirmed", 16, 20, 10)
        saved = self.project.decisions_for(member)[case["case_id"]]
        self.assertEqual(saved["edit_count"], 1)
        self.assertEqual(saved["last_edit_reason"], "球心点偏，重新校正")
        self.assertEqual(self.template.read_bytes(), original)

    def test_resolve_original_inputs(self):
        video, annotation = self.project.resolve_inputs(self.cases[3])
        self.assertEqual(video.suffix, ".mp4")
        self.assertEqual(annotation.suffix, ".json")
        self.assertTrue(video.is_file() and annotation.is_file())

    def test_zoom_transform_round_trip(self):
        transform = ReviewTransform.fit(1920, 1080, 1000, 564, 2.5, (1000, 500))
        point = (1012.5, 522.25)
        displayed = transform.source_to_display(*point)
        restored = transform.display_to_source(*displayed)
        self.assertIsNotNone(restored)
        self.assertAlmostEqual(restored[0], point[0], delta=2)
        self.assertAlmostEqual(restored[1], point[1], delta=2)

    def test_click_moves_single_pending_cross_without_mode_key(self):
        viewer = AdjudicationViewer.__new__(AdjudicationViewer)
        viewer.meta = {"width": 1000, "height": 500}
        viewer.playing = True
        viewer.pending = None
        viewer.zoom = 1.0
        viewer.zoom_center = None
        viewer.message = ""
        viewer.on_mouse(cv2.EVENT_LBUTTONDOWN, 200, viewer.HEADER + 100, 0, None)
        first = viewer.pending
        viewer.on_mouse(cv2.EVENT_LBUTTONDOWN, 400, viewer.HEADER + 200, 0, None)
        self.assertIsNotNone(first)
        self.assertNotEqual(viewer.pending, first)
        self.assertFalse(viewer.playing)

    def test_comparison_crosses_only_appear_on_their_own_frame(self):
        class FakeProject:
            def decisions_for(self, member):
                return {"case": {"decision": "confirmed", "final_frame_id": 8,
                                 "final_x": 120.0, "final_y": 120.0}}
        viewer = AdjudicationViewer.__new__(AdjudicationViewer)
        viewer.project, viewer.member = FakeProject(), "B"
        viewer.case = {"case_id": "case",
                       "initial_only_events": [{"frame_id": 8, "x": 100.0, "y": 100.0}],
                       "review_only_events": [{"frame_id": 23, "x": 300.0, "y": 300.0}],
                       "initial_uncertain": [], "review_uncertain": []}
        viewer.show_human = True
        transform = ReviewTransform.fit(500, 500, viewer.MAIN_W, viewer.MAIN_H, 1.0, None)
        viewer.frame_id = 8
        canvas = np.zeros((viewer.HEADER + viewer.MAIN_H, viewer.MAIN_W, 3), np.uint8)
        viewer._draw_human(canvas, transform)
        initial = transform.source_to_display(100, 100)
        review = transform.source_to_display(300, 300)
        self.assertGreater(np.count_nonzero(canvas[viewer.HEADER + initial[1] - 12:viewer.HEADER + initial[1] + 13,
                                                   initial[0] - 12:initial[0] + 13]), 0)
        self.assertEqual(np.count_nonzero(canvas[viewer.HEADER + review[1] - 12:viewer.HEADER + review[1] + 13,
                                                 review[0] - 12:review[0] + 13]), 0)


if __name__ == "__main__":
    unittest.main()
