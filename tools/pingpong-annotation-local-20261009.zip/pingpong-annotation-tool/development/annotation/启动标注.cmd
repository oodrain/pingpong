@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Annotation.ps1"
