"""Default native entry: local video import, annotation, review and standard export."""
from __future__ import annotations

import argparse
import queue
import sys
import threading
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw

from annotation_core import OutputLock, Session, write_image
from annotate import Viewer, font
from gui_dialogs import ask, pick_file, pick_folder
from local_workflow import DEFAULT_WORK, MEMBERS, ROOT, LocalProject, make_entry, remember, scan_folder, settings
from submission import read_json, validate_folder

TITLE = 'Local Pingpong Annotation'
VIDEO_FILTER = 'Video|*.mp4;*.avi;*.mov;*.mkv|All files|*.*'
WIDTH, HEIGHT = 1360, 820


class LocalWindow:
    def __init__(self, project, *, persist=True):
        self.project, self.persist = project, persist
        saved = settings() if persist else {}
        self.member = saved.get('member', 'A')
        if self.member not in MEMBERS:
            self.member = 'A'
        self.phase = 'initial'
        self.selected = None
        self.selection = set()
        self.scroll = 0
        self.message = '先选择成员，再点击批量导入文件夹；视频和配套JSON会自动匹配。'
        self.busy = False
        self.more = False
        self.jobs = queue.Queue()
        self.rows, self.buttons = [], []
        self.pending = None
        self.states = {}
        self.refresh()

    def refresh(self):
        self.states = {}
        for entry in self.project.entries:
            try:
                self.states[entry['entry_id']] = self.project.status(entry, self.member, self.phase)
            except (ValueError, OSError, KeyError, TypeError) as error:
                self.states[entry['entry_id']] = '工作记录需核对：' + str(error)
        ids = {entry['entry_id'] for entry in self.project.entries}
        self.selection &= ids
        if self.selected not in ids:
            self.selected = None
        self.scroll = min(max(self.scroll, 0), max(0, len(ids) - 12))
        if self.persist:
            remember(member=self.member, work_root=str(self.project.root))

    def current(self):
        entry = next((item for item in self.project.entries if item['entry_id'] == self.selected), None)
        if entry is None:
            raise ValueError('请先点击清单选择一段视频。')
        return entry

    def selected_entries(self):
        return [entry for entry in self.project.entries if entry['entry_id'] in self.selection]

    def draw(self):
        image = Image.new('RGB', (WIDTH, HEIGHT), (24, 28, 35))
        paint = ImageDraw.Draw(image)
        self.buttons, self.rows = [], []
        def label(x, y, value, size=17, color=(225, 229, 237)):
            paint.text((x, y), str(value), font=font(size), fill=color)
        def button(box, title, action, active=False):
            paint.rectangle(box, fill=(52, 90, 125) if active else (45, 51, 62))
            label(box[0] + 9, box[1] + 8, title)
            self.buttons.append((box, action))
        label(18, 12, '乒乓球视频标注', 25)
        label(18, 50, '一次选择视频和配套JSON所在的文件夹，自动配对，标注后导出交回。')
        for i, member in enumerate(MEMBERS):
            button((18+i*58, 85, 68+i*58, 123), member, 'member:' + member, self.member == member)
        button((270, 85, 450, 123), '批量导入文件夹', 'scan')
        button((465, 85, 615, 123), '打开标注', 'open')
        button((630, 85, 780, 123), '导出结果', 'export')
        button((795, 85, 945, 123), '收起功能' if self.more else '更多功能', 'more', self.more)
        if self.more:
            button((979, 85, 1070, 123), '初标', 'phase:initial', self.phase == 'initial')
            button((1085, 85, 1195, 123), '独立复核', 'phase:review', self.phase == 'review')
            button((1210, 85, 1340, 123), '取消选择', 'clear')
            label(18, 136, '工作目录：' + str(self.project.root)[:109], 16)
            for box, title, action in (
                ((18, 174, 198, 213), '单个视频＋JSON', 'pair'),
                ((211, 174, 342, 213), '重新配对', 'bind'),
                ((355, 174, 525, 213), '导入结果/复核', 'import'),
                ((538, 174, 668, 213), '批量导出', 'batch'),
                ((681, 174, 836, 213), '选择工作目录', 'work'),
                ((849, 174, 982, 213), '文件详情', 'details'),
                ((995, 174, 1130, 213), '移除清单项', 'remove'),
                ((1143, 174, 1338, 213), '批量导入复核', 'import_reviews')):
                button(box, title, action)
        else:
            button((970, 85, 1165, 123), '第三复核/裁决', 'adjudicate')
            label(18, 136, ('当前：独立复核' if self.phase == 'review' else '当前：初标') + ' · 进度自动保存，下次打开可继续。', 16)
            label(18, 184, '文件夹及其子文件夹会一并导入。双击视频开始，按N继续下一段。', 17)
        paint.rectangle((15, 230, WIDTH-15, 263), fill=(39, 45, 55))
        for x, value in ((25, '视频编号'), (150, '标注状态'), (610, '视频文件'), (1020, '配套JSON')):
            label(x, 235, value)
        for index, entry in enumerate(self.project.entries[self.scroll:self.scroll+12]):
            top = 269 + index*32
            selected = entry['entry_id'] in self.selection
            if selected:
                paint.rectangle((15, top, WIDTH-15, top+31), fill=(43, 65, 85))
            label(25, top+4, entry['video_id'], 16)
            label(150, top+4, self.states.get(entry['entry_id'], '')[:26], 16)
            video = str(entry.get('video') or '尚未配对')
            annotation = str(entry['annotation'])
            video_label = (video if len(video) <= 42 else '…' + video[-41:]) if self.more else Path(video).name
            label(610, top+4, video_label[:42], 16)
            label(1020, top+4, Path(annotation).name[:27], 16)
            self.rows.append((top, top+32, entry['entry_id']))
        label(18, 664, '点击选择 · ' + ('Ctrl＋点击多选 · ' if self.more else '') + '滚轮翻页 · Enter打开 · Q退出', 16)
        if self.more:
            label(18, 706, '批量：导出选中项；未选中时导出本阶段全部已有记录', 17)
            button((1100, 700, 1338, 742), '刷新状态', 'refresh')
        else:
            label(18, 706, '操作：A/D逐帧 · 空格播放 · 左键点球心＋Enter保存 · S保存 · Q返回列表', 17)
        label(18, 753, 'C人工声明完成；无触台需原因。自己的结果可接续，别人的已完成初标用于独立复核。', 17)
        label(18, 785, self.message[:96], 16, (255, 210, 128))
        if self.busy:
            label(1120, 50, '正在处理…', 17, (255, 210, 128))
        return cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)

    def mouse(self, event, x, y, flags, _):
        if self.busy:
            return
        if event == cv2.EVENT_MOUSEWHEEL:
            delta = (flags >> 16) & 0xffff
            if delta >= 0x8000:
                delta -= 0x10000
            self.scroll += -3 if delta > 0 else 3
            self.scroll = min(max(self.scroll, 0), max(0, len(self.project.entries)-12))
        elif event in (cv2.EVENT_LBUTTONDOWN, cv2.EVENT_LBUTTONDBLCLK):
            for top, bottom, key in self.rows:
                if top <= y < bottom:
                    self.selected = key
                    if flags & cv2.EVENT_FLAG_CTRLKEY:
                        self.selection ^= {key}
                        if key not in self.selection:
                            self.selected = next(iter(self.selection), None)
                    else:
                        self.selection = {key}
                    if event == cv2.EVENT_LBUTTONDBLCLK:
                        self.pending = 'open'
                    return
            for (left, top, right, bottom), action in self.buttons:
                if left <= x <= right and top <= y <= bottom:
                    self.pending = action
                    return

    def job(self, action, callback):
        self.busy = True
        self.message = '正在核对文件或准备缓存，请稍候……'
        def run():
            try:
                self.jobs.put((callback, action(), None))
            except Exception as error:
                self.jobs.put((callback, None, error))
        threading.Thread(target=run, daemon=True).start()

    def poll(self):
        try:
            callback, result, error = self.jobs.get_nowait()
        except queue.Empty:
            return
        self.busy = False
        if error:
            raise error
        callback(result)
        self.refresh()

    def show_viewer(self, result):
        session, annotation = result
        cv2.destroyWindow(TITLE)
        try:
            while True:
                with OutputLock(session.output):
                    session = Session(session.output, read_json(session.output / 'session.json'))
                    session.frames_dir = Path(session.state['cache']['directory'])
                    action = Viewer(session, annotation).run()
                if action != 'next':
                    break
                at = self.project.entries.index(self.current())
                entry = next((item for item in self.project.entries[at+1:]
                              if self.project.status(item, self.member, self.phase) in ('未开始', '进行中')), None)
                if entry is None:
                    break
                self.selected = entry['entry_id']
                self.selection = {self.selected}
                session, annotation = self.project.open(entry, self.member, self.phase)
        finally:
            cv2.namedWindow(TITLE, cv2.WINDOW_AUTOSIZE)
            cv2.setMouseCallback(TITLE, self.mouse)
            self.refresh()
            self.message = '工作记录已保存，点击导出当前或批量导出生成交回文件。'

    def action(self, action):
        if action == 'more':
            self.more = not self.more
        elif action.startswith('member:'):
            self.member = action.split(':')[1]
            self.refresh()
        elif action.startswith('phase:'):
            self.phase = action.split(':')[1]
            self.refresh()
        elif action == 'clear':
            self.selected, self.selection = None, set()
        elif action == 'refresh':
            self.refresh()
        elif action == 'adjudicate':
            saved = settings() if self.persist else {}
            package = pick_folder(
                '选择裁决包（目录内应有 decision_template.jsonl）',
                initial=saved.get('adjudication_package', str(ROOT)))
            if not package:
                return
            data_root = pick_folder(
                '选择同时包含 A、B、C、D 文件夹的数据根目录',
                initial=saved.get('adjudication_data_root', str(Path.home() / 'Desktop')))
            if not data_root:
                return
            if self.persist:
                remember(adjudication_package=package, adjudication_data_root=data_root)
            from adjudication import AdjudicationProject, AdjudicationWindow
            adjudication = AdjudicationProject(Path(package), Path(data_root))
            cv2.destroyWindow(TITLE)
            try:
                AdjudicationWindow(adjudication, self.member).run()
            finally:
                cv2.namedWindow(TITLE, cv2.WINDOW_AUTOSIZE)
                cv2.setMouseCallback(TITLE, self.mouse)
                self.message = '第三复核结果已单独保存；初标和原复核标签没有被修改。'
        elif action == 'work':
            path = pick_folder('选择保存清单、session、历史和缓存的工作目录', initial=str(self.project.root))
            if path:
                self.project = LocalProject(path)
                self.selected, self.selection = None, set()
                self.refresh()
                self.message = '已切换工作目录，旧目录内容保留。'
        elif action == 'pair':
            video = pick_file('选择视频', file_filter=VIDEO_FILTER)
            if not video:
                return
            annotation = pick_file('选择该视频配套的官方对象JSON', file_filter='JSON|*.json')
            if annotation:
                entry = make_entry(annotation, video)
                prior = next((item for item in self.project.entries if item['entry_id'] == entry['entry_id']), None)
                if prior:
                    self.project.bind(prior, video, annotation)
                else:
                    self.project.add([entry])
                self.selected = entry['entry_id']
                self.selection = {self.selected}
                self.refresh()
                self.message = '已加入清单，打开时核对实际帧数、尺寸和输入哈希。'
        elif action == 'scan':
            path = pick_folder('批量导入：选择包含视频和配套JSON的文件夹，子文件夹也会扫描')
            if path:
                def finished(result):
                    entries, errors = result
                    self.project.add(entries)
                    ready = sum(not self.project.pairing_issue(entry) for entry in self.project.entries)
                    self.message = f'清单共{len(self.project.entries)}段，可打开{ready}段，需处理{len(self.project.entries)-ready}段。双击视频开始标注。'
                    if errors:
                        ask('部分JSON无法导入', '\n'.join(errors), confirm=True)
                self.job(lambda: scan_folder(path), finished)
        elif action in ('bind', 'details'):
            entry = self.current()
            if action == 'details':
                ask('文件详情', f"编号：{entry['video_id']}\n视频：{entry.get('video')}\nJSON：{entry['annotation']}\n候选：\n"
                    + '\n'.join(entry.get('candidates', [])), confirm=True)
                return
            video = pick_file('选择正确视频', file_filter=VIDEO_FILTER)
            if not video:
                return
            annotation = pick_file('重新选择配套对象JSON', initial=str(Path(entry['annotation']).parent), file_filter='JSON|*.json')
            if annotation:
                self.project.bind(entry, video, annotation)
                self.refresh()
                self.message = '重新配对完成；已有记录仅在输入哈希相同时恢复。'
        elif action == 'remove':
            selected = self.selected_entries()
            if selected and ask('移除清单', '仅移除清单项，保留视频、JSON和已有工作记录。确认？', confirm=True):
                ids = {item['entry_id'] for item in selected}
                self.project.entries = [item for item in self.project.entries if item['entry_id'] not in ids]
                self.project.save()
                self.refresh()
        elif action == 'open':
            entry, member, phase = self.current(), self.member, self.phase
            self.job(lambda: self.project.open(entry, member, phase), self.show_viewer)
        elif action == 'import':
            entry, member = self.current(), self.member
            source = pick_folder('选择标准结果的initial/review文件夹（保留成员/视频/轮次目录）')
            if not source:
                return
            meta = validate_folder(Path(source))
            review_source = None
            if meta['annotator'] == member and meta['round'] == 'review':
                review_source = pick_folder('选择此复核绑定版本的完整初标initial文件夹')
                if not review_source:
                    return
            def finished(result):
                session, _ = result
                self.phase = session.round
                self.message = '标准结果已导入，打开视频即可接续；完成记录按E保留历史后编辑。'
            self.job(lambda: self.project.import_result(entry, member, source, review_source), finished)
        elif action == 'import_reviews':
            member = self.member
            source_root = pick_folder('批量导入复核：选择labels\\A或包含已完成initial的目录')
            if not source_root:
                return
            def finished(report):
                self.phase = 'review'
                self.message = (f"批量复核导入成功{len(report['successes'])}段，"
                                f"跳过已有{len(report['skipped'])}段，失败{len(report['failures'])}段。")
                lines = [
                    '成功：' + (', '.join(report['successes']) or '无'),
                    '跳过已有：' + (', '.join(report['skipped']) or '无'),
                    '', '失败：', *(report['failures'] or ['无'])]
                ask('批量导入复核', '\n'.join(lines), confirm=True)
            self.job(lambda: self.project.import_review_batch(self.project.entries, member, source_root), finished)
        elif action in ('export', 'batch'):
            if action == 'export':
                entries = [self.current()]
            else:
                entries = self.selected_entries() or [entry for entry in self.project.entries
                           if (self.project.workspace(entry, self.member, self.phase) / 'session.json').exists()]
            if not entries:
                raise ValueError('本成员/阶段暂无工作记录可以导出。')
            saved = settings() if self.persist else {}
            destination = pick_folder('选择交回根目录（自动生成成员/视频/轮次）', initial=saved.get('export_root', str(ROOT)))
            if not destination:
                return
            if self.persist:
                remember(export_root=destination)
            member, phase = self.member, self.phase
            def finished(report):
                self.message = f"导出成功{len(report['successes'])}段，失败{len(report['failures'])}段。"
                from annotation_core import write_json
                write_json(self.project.root / 'last_export_report.json', report)
                ask('导出结果', '\n'.join(['成功：', *report['successes'], '', '失败：', *report['failures']]), confirm=True)
            self.job(lambda: self.project.export_batch(entries, member, phase, destination), finished)

    def run(self, *, smoke_test=False):
        cv2.namedWindow(TITLE, cv2.WINDOW_AUTOSIZE)
        cv2.setMouseCallback(TITLE, self.mouse)
        started = time.perf_counter()
        try:
            while True:
                cv2.imshow(TITLE, self.draw())
                key = cv2.waitKeyEx(30)
                if cv2.getWindowProperty(TITLE, cv2.WND_PROP_VISIBLE) < 1:
                    if self.busy:
                        cv2.namedWindow(TITLE, cv2.WINDOW_AUTOSIZE)
                        cv2.setMouseCallback(TITLE, self.mouse)
                    else:
                        break
                if smoke_test and time.perf_counter() - started >= 1.5:
                    break
                if key in (27, ord('q'), ord('Q')) and not self.busy:
                    break
                if key in (10, 13) and not self.busy:
                    self.pending = 'open'
                action, self.pending = self.pending, None
                try:
                    self.poll()
                    if action and not self.busy:
                        self.action(action)
                except Exception as error:
                    self.message = str(error)
                    print('暂停：' + self.message, flush=True)
                    ask('操作暂停', self.message + '\n既有标签保留。', confirm=True)
        finally:
            cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(description='本地视频＋对象JSON导入、标注及标准导出')
    parser.add_argument('--work-root', type=Path)
    parser.add_argument('--smoke-test', action='store_true', help='短暂打开入口，不修改清单或标注')
    parser.add_argument('--preview', type=Path, help='生成入口预览，不记录标注')
    args = parser.parse_args()
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    path = args.work_root or settings().get('work_root') or DEFAULT_WORK
    window = LocalWindow(LocalProject(path), persist=not (args.smoke_test or args.preview))
    if args.preview:
        write_image(args.preview, window.draw())
    else:
        window.run(smoke_test=args.smoke_test)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
