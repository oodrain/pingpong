# 乒乓球本地标注工具

默认流程：选择成员 → 导入视频和官方对象JSON → 初标或独立复核 → 保存 → 导出标准结果。
文件分配、传输及汇总由组长在工具外组织，不要求固定数据目录或任务表。

## 启动与导入

按[组员上手说明](../../docs/guides/标注工具_组员上手说明.md)安装Python 3.12 x64和锁定依赖，双击根目录“启动标注.cmd”。也可运行：

~~~powershell
& './.venv-annotation/Scripts/python.exe' development/annotation/local_annotation.py
~~~

默认界面提供“批量导入文件夹”“打开标注”“导出结果”。选择A/B/C/D，一次选择包含视频和JSON的文件夹，工具递归扫描、自动配对并生成清单，双击视频即可。
视频和JSON可以分别放在两个子文件夹，不必逐段选择。只有缺失、歧义或重复编号需要人工处理。单文件导入、重新配对、结果导入/复核及工作目录设置在“更多功能”中。
视频和配套对象JSON均必需，编号沿用03_007等格式。工具按JSON的video_id、video_path和本地位置匹配。
缺失或多个候选须用“手动配对/重新定位”明确选择；重复编号须移除重复清单项或另选工作目录。移除清单不删除原文件或标签。

首次打开顺序解码，核对实际帧数、尺寸、帧率，不匹配时停止。视频或JSON哈希改变时不能恢复旧记录。
输入搬家后重新定位相同文件即可，不能把标签套到其他视频。

## 标注操作

|操作|作用|
|---|---|
|A/D或左右键|前一帧/后一帧|
|空格、G|播放暂停、按0基帧号跳转|
|B、Z|参考框/轨迹开关、原图局部放大|
|1＋左键＋Enter|触台球心，保存原图像素坐标|
|2/3/4/5＋Enter|触网/触地/击球/其他，必填依据，坐标可空|
|I/O/U|疑难起点/终点/原因并保存|
|点击右侧记录＋Delete/X|删除记录|
|K、S|清除未保存草稿、保存（也每15秒自动保存）|
|C|人工声明已完整检查并完成，不强制显示过全部帧|
|E|写明原因，保留历史后重新编辑并取消完成|
|Q/L/Esc、N|保存返回视频列表、保存后尝试下一段|
|H|独立复核完成后显示初标对照|
|V|可选记录当前帧已明确检查，不是完成前提|

完成前先保存或清除草稿；无确定触台必须说明原因。完成后冻结记录，人工声明与实际显示进度分别记录。
缩放/放大点选均转换回原图像素。看不清时记疑难，不强填答案。

## 工作记录、接续与复核

默认工作目录是工具包内outputs/local_annotation，可在窗口另选并记住。

~~~text
outputs/local_annotation/
  local_project.json             # 本机导入清单
  A/03_007/initial/session.json  # 初标工作记录
  B/03_007/review/session.json   # 复核及固定初标快照
  _frames/                      # 按输入身份隔离的共享PNG缓存
  _export_backups/               # 正式结果更新前的备份
~~~

相同输入恢复保留标签和历史，缓存缺失会重新解码。关闭所有窗口后可清理_frames，保留成员工作目录。
工作目录有输出锁，两个窗口不能同时修改同一session。

换电脑接续：导入同一视频和JSON，选同一成员，在“更多功能”中点击“导入结果/复核”，选择自己的initial或review目录。
已有对应工作记录时拒绝覆盖，直接打开恢复或换工作目录。恢复review还需其绑定版本的完整初标包。

独立复核：选另一成员，导入对方已完成的initial包。工具创建独立review和固定来源快照，不接管初标人。
完成前隐藏初标人工标注，按C后才可H对照并产生review_comparison.json。
帧差≤1、距离≤50像素的一对一匹配用于判断双方是否一致。进入第三复核后，只要能确认触台并标出可靠球心，包括二次弹跳、桌边反弹或可判断的遮挡，都统一保留为触台；只有纯粹无法判断的条目才记为疑难并从当前训练标签剔除。
可访问的初标来源改变时清单显示“复核过期”；旧记录保留。重新复核请用新工作目录导入最新初标。
来源不在本机时无法获知远端更新，组长汇总后应运行标准校验。

## 第三人盲审裁决

主界面选定A/B/C/D后，在“更多功能”收起时点击“第三复核/裁决”。先选择含`decision_template.jsonl`的裁决包，再选择同时含A/B/C/D目录的数据根目录。

`adjudication.py`按`case_id`稳定排序后做均衡分配，每条只在初标者、原复核者之外的两人中选择负载较小者。界面从原始完整视频读取争议范围，帧号始终是原视频0基帧号，不使用裁剪视频的相对帧号。

完成前隐藏双方人工标签。第三人先保存`confirmed`、`no_bounce`或`uncertain`之一，再按C确认完成。`confirmed`包含所有能够确认的触台（包括可判断的干扰触台），必须保存准确帧和球心；`no_bounce`表示确认不是触台；只有确实无法判断时才选`uncertain`并填写原因。按C后H才可显示双方结果作对照。球心只在各自所属帧显示，画面不附加字母或帧号；左键可反复移动待保存十字，最后按一次Enter保存，无需先按1。已完成条目可按E填写修改原因后解冻，旧结果备份到`third_review/history`，修改后必须重新按C完成。

四人完成后，汇总时保留全部`confirmed`，忽略`no_bounce`，并将`uncertain`单独留档且从当前训练标签中剔除。第三复核结果作为本轮最终判断，不再转交第四人。

结果按成员原子写入`裁决包/third_review/<成员>.jsonl`，原模板和初标/复核包保持只读。重复提交会把旧条目备份到`third_review/history`。也可直接运行：

~~~powershell
& './.venv-annotation/Scripts/python.exe' development/annotation/adjudication.py `
  --package '裁决包目录' --data-root '包含A、B、C、D的目录' --member B
~~~

只检查分配统计、不打开窗口：

~~~powershell
& './.venv-annotation/Scripts/python.exe' development/annotation/adjudication.py `
  --package '裁决包目录' --data-root '包含A、B、C、D的目录' --member B --summary
~~~

## 标准导出

点击默认界面的“导出结果”，或在“更多功能”中使用“批量导出”，选择目标根目录。批量处理选中项；未选中时处理当前成员/阶段全部已有记录。
每段分别报告成功失败，完整报告也保存为工作目录中的last_export_report.json。允许导出草稿，completed明确区分。导出根目录不能等于工作目录。

~~~text
交回目录/A/03_007/initial/
  metadata.json
  events.jsonl
  uncertain.jsonl
  non_table_events.jsonl
~~~

四文件始终生成，空JSONL保留。初次版本1，内容改变后自动升版本并备份，不变不重写；换目标目录也保留已导出的版本。
复核导出在目标树缺少初标时附带固定来源包；已有初标保留，由校验报告过期版本。
详细字段见[提交标准](../../docs/guides/标注文件与GitHub提交标准.md)。

~~~powershell
python development/annotation/submission.py validate labels
python development/annotation/submission.py validate labels --require-current-reviews
~~~

默认校验格式、范围、目录和复核来源；任务分配校验需显式--tasks。--verify-inputs也需--tasks提供输入映射，可配--data-root。
CLI原有export默认输出v1；本地模式使用--schema-version 2 --auto-version导出v2。

## 旧入口与验证

旧session、v1标准包和单视频CLI继续支持，旧标签不自动迁移。team_annotation.py保留原任务流程和完成覆盖要求。

~~~powershell
python development/annotation/annotate.py --video 视频路径 --annotation JSON路径 --output 独立工作目录 --annotator A
python development/annotation/team_annotation.py
python -m unittest discover -s development/annotation -p 'test*.py' -v
python development/annotation/local_annotation.py --smoke-test --work-root outputs/local_smoke
python development/annotation/package_tool.py
~~~

工具包仅含代码、安装启动脚本、文档和兼容任务表，不含实际输入、模型、真实标签或环境。
