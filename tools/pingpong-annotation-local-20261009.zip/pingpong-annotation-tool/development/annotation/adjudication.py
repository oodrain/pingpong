from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from PIL import Image, ImageDraw

from annotate import font
from annotation_core import atomic_text, prepare, read_image


MEMBERS = ("A", "B", "C", "D")
DECISIONS = ("confirmed", "no_bounce", "uncertain")


def _paint_texts(image: np.ndarray, items: list[tuple[str, tuple[int, int], int, tuple[int, int, int], bool]]) -> np.ndarray:
    """Paint all Chinese text in one PIL conversion to keep playback responsive."""
    pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil)
    for content, position, size, color, bold in items:
        rgb = (color[2], color[1], color[0])
        draw.text(position, str(content), font=font(size), fill=rgb,
                  stroke_width=1 if bold else 0, stroke_fill=rgb)
    return cv2.cvtColor(np.asarray(pil), cv2.COLOR_RGB2BGR)


@dataclass(frozen=True)
class ReviewTransform:
    offset_x: int
    offset_y: int
    display_w: int
    display_h: int
    origin_x: int
    origin_y: int
    source_w: int
    source_h: int

    @classmethod
    def fit(cls, width: int, height: int, box_w: int, box_h: int, zoom: float,
            center: tuple[float, float] | None):
        crop_w = max(1, round(width / zoom))
        crop_h = max(1, round(height / zoom))
        cx, cy = center or (width / 2, height / 2)
        ox = min(max(round(cx - crop_w / 2), 0), width - crop_w)
        oy = min(max(round(cy - crop_h / 2), 0), height - crop_h)
        scale = min(box_w / crop_w, box_h / crop_h)
        dw, dh = max(1, round(crop_w * scale)), max(1, round(crop_h * scale))
        return cls((box_w - dw) // 2, (box_h - dh) // 2, dw, dh, ox, oy, crop_w, crop_h)

    def source_crop(self) -> tuple[int, int, int, int]:
        return self.origin_x, self.origin_y, self.origin_x + self.source_w, self.origin_y + self.source_h

    def source_to_display(self, x: float, y: float) -> tuple[int, int]:
        return (round(self.offset_x + (x - self.origin_x) * self.display_w / self.source_w),
                round(self.offset_y + (y - self.origin_y) * self.display_h / self.source_h))

    def display_to_source(self, x: int, y: int) -> tuple[float, float] | None:
        if not (self.offset_x <= x < self.offset_x + self.display_w
                and self.offset_y <= y < self.offset_y + self.display_h):
            return None
        return (self.origin_x + (x - self.offset_x) * self.source_w / self.display_w,
                self.origin_y + (y - self.offset_y) * self.source_h / self.display_h)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as fh:
        for number, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path.name} 第 {number} 行不是有效 JSON: {exc}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"{path.name} 第 {number} 行必须是对象")
            rows.append(value)
    return rows


def _jsonl(rows: list[dict[str, Any]]) -> str:
    return "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows)


def _event_frame(event: dict[str, Any]) -> int | None:
    value = event.get("frame_id")
    return int(value) if isinstance(value, (int, float)) else None


def _decision_events(record: dict[str, Any] | None) -> list[dict[str, float | int]]:
    """Return normalized confirmed points, including legacy single-point records."""
    if not record or record.get("decision") != "confirmed":
        return []
    events: list[dict[str, float | int]] = []
    raw = record.get("final_events")
    if isinstance(raw, list):
        for item in raw:
            if (isinstance(item, dict)
                    and isinstance(item.get("frame_id"), (int, float))
                    and isinstance(item.get("x"), (int, float))
                    and isinstance(item.get("y"), (int, float))):
                events.append({
                    "frame_id": int(item["frame_id"]),
                    "x": round(float(item["x"]), 3),
                    "y": round(float(item["y"]), 3),
                })
    elif (isinstance(record.get("final_frame_id"), (int, float))
          and isinstance(record.get("final_x"), (int, float))
          and isinstance(record.get("final_y"), (int, float))):
        events.append({
            "frame_id": int(record["final_frame_id"]),
            "x": round(float(record["final_x"]), 3),
            "y": round(float(record["final_y"]), 3),
        })
    return sorted(events, key=lambda item: (int(item["frame_id"]), float(item["x"]), float(item["y"])))


class AdjudicationProject:
    """Read-only dispute inputs plus per-member third-review decisions."""

    def __init__(self, package_root: Path, data_root: Path):
        self.package_root = Path(package_root).resolve()
        self.data_root = Path(data_root).resolve()
        self.template_path = self.package_root / "decision_template.jsonl"
        if not self.template_path.is_file():
            raise FileNotFoundError(f"未找到 {self.template_path}")
        self.cases = sorted(_read_jsonl(self.template_path), key=lambda row: str(row.get("case_id", "")))
        if not self.cases:
            raise ValueError("decision_template.jsonl 中没有争议条目")
        self._validate_cases()
        self.assignments = self._balanced_assignments()

    def _validate_cases(self) -> None:
        seen: set[str] = set()
        required = ("case_id", "video_id", "initial_annotator", "reviewer", "frame_start", "frame_end")
        for case in self.cases:
            missing = [key for key in required if key not in case]
            if missing:
                raise ValueError(f"争议条目缺少字段: {', '.join(missing)}")
            case_id = str(case["case_id"])
            if case_id in seen:
                raise ValueError(f"重复 case_id: {case_id}")
            seen.add(case_id)
            if case["initial_annotator"] not in MEMBERS or case["reviewer"] not in MEMBERS:
                raise ValueError(f"{case_id} 的标注者不在 A/B/C/D 中")
            if case["initial_annotator"] == case["reviewer"]:
                raise ValueError(f"{case_id} 的初标者和复核者不能相同")

    def _balanced_assignments(self) -> dict[str, str]:
        eligible = {
            index: tuple(member for member in MEMBERS
                         if member not in {case["initial_annotator"], case["reviewer"]})
            for index, case in enumerate(self.cases)
        }
        base, remainder = divmod(len(self.cases), len(MEMBERS))
        # Try every deterministic placement of the remainder. A small augmenting-path
        # matcher makes the result balanced even when a greedy pass meets constraints.
        import itertools
        for raised in itertools.combinations(MEMBERS, remainder):
            capacities = {member: base + (member in raised) for member in MEMBERS}
            member_cases: dict[str, list[int]] = {member: [] for member in MEMBERS}
            assigned: dict[int, str] = {}

            def place(case_index: int, seen_cases: set[int], seen_members: set[str]) -> bool:
                if case_index in seen_cases:
                    return False
                seen_cases.add(case_index)
                for member in sorted(eligible[case_index], key=lambda item: (len(member_cases[item]), item)):
                    if member in seen_members:
                        continue
                    seen_members.add(member)
                    if len(member_cases[member]) < capacities[member]:
                        assigned[case_index] = member
                        member_cases[member].append(case_index)
                        return True
                    for displaced in tuple(member_cases[member]):
                        old = assigned[displaced]
                        member_cases[old].remove(displaced)
                        del assigned[displaced]
                        if place(displaced, seen_cases, seen_members):
                            assigned[case_index] = member
                            member_cases[member].append(case_index)
                            return True
                        assigned[displaced] = old
                        member_cases[old].append(displaced)
                return False

            if all(place(index, set(), set()) for index in range(len(self.cases))):
                return {str(self.cases[index]["case_id"]): assigned[index]
                        for index in range(len(self.cases))}
        raise ValueError("无法在排除初标者和复核者后均衡分配第三复核任务")

    def assigned_to(self, case: dict[str, Any]) -> str:
        return self.assignments[str(case["case_id"])]

    def cases_for(self, member: str) -> list[dict[str, Any]]:
        if member not in MEMBERS:
            raise ValueError("成员必须是 A、B、C 或 D")
        return [case for case in self.cases if self.assigned_to(case) == member]

    def decision_path(self, member: str) -> Path:
        return self.package_root / "third_review" / f"{member}.jsonl"

    def decisions_for(self, member: str) -> dict[str, dict[str, Any]]:
        path = self.decision_path(member)
        if not path.is_file():
            return {}
        result: dict[str, dict[str, Any]] = {}
        for row in _read_jsonl(path):
            case_id = str(row.get("case_id", ""))
            if case_id:
                result[case_id] = row
        return result

    def status(self, member: str, case: dict[str, Any]) -> str:
        row = self.decisions_for(member).get(str(case["case_id"]))
        if not row:
            return "pending"
        return str(row.get("decision", "pending")) if row.get("completed") is True else "in_progress"

    def resolve_inputs(self, case: dict[str, Any]) -> tuple[Path, Path]:
        video_id = str(case["video_id"])
        if "_" not in video_id:
            raise ValueError(f"无法解析 video_id: {video_id}")
        scene, clip = video_id.split("_", 1)
        owner = str(case["initial_annotator"])
        video = self.data_root / owner / "videos" / scene / f"{clip}.mp4"
        annotation = self.data_root / owner / "json" / scene / f"{clip}.json"
        if not video.is_file() or not annotation.is_file():
            raise FileNotFoundError(
                "找不到原视频或检测 JSON。请选择同时包含 A/B/C/D 文件夹的目录。\n"
                f"视频: {video}\nJSON: {annotation}"
            )
        return video, annotation

    def prepare_case(self, case: dict[str, Any]):
        video, annotation = self.resolve_inputs(case)
        video_id = str(case["video_id"])
        work = self.package_root / "_third_review_work" / video_id
        frames = self.package_root / "_third_review_cache" / video_id
        return prepare(video, annotation, work, frames_dir=frames, completion_policy="manual_attestation")

    def save_decision(
        self,
        member: str,
        case: dict[str, Any],
        decision: str,
        frame_id: int | None = None,
        x: float | None = None,
        y: float | None = None,
        notes: str = "",
    ) -> dict[str, Any]:
        if member != self.assigned_to(case):
            raise ValueError("该争议条目未分配给当前成员")
        if member in {case["initial_annotator"], case["reviewer"]}:
            raise ValueError("第三复核者不能是本条的初标者或复核者")
        if decision not in DECISIONS:
            raise ValueError("未知裁决结果")
        if decision == "confirmed":
            if frame_id is None or x is None or y is None:
                raise ValueError("确认触台必须记录帧号和球心")
            if not int(case["frame_start"]) <= int(frame_id) <= int(case["frame_end"]):
                raise ValueError("触台帧必须在当前争议片段范围内")
        else:
            frame_id = None
            x = None
            y = None
        if decision == "uncertain" and not notes.strip():
            raise ValueError("疑难必须填写原因")

        path = self.decision_path(member)
        path.parent.mkdir(parents=True, exist_ok=True)
        current = self.decisions_for(member)
        old = current.get(str(case["case_id"]))
        final_events: list[dict[str, float | int]] = []
        if decision == "confirmed":
            if old and old.get("completed") is True:
                raise ValueError("本条已经完成，请先按 E 重新编辑")
            final_events = _decision_events(old)
            new_event = {
                "frame_id": int(frame_id),
                "x": round(float(x), 3),
                "y": round(float(y), 3),
            }
            # A table-bounce event has one center per frame. Re-clicking the same
            # frame corrects that point; choosing another frame appends a new one.
            final_events = [item for item in final_events if item["frame_id"] != new_event["frame_id"]]
            final_events.append(new_event)
            final_events.sort(key=lambda item: (int(item["frame_id"]), float(item["x"]), float(item["y"])))

        record = {
            "case_id": str(case["case_id"]),
            "video_id": str(case["video_id"]),
            "initial_annotator": case["initial_annotator"],
            "reviewer": case["reviewer"],
            "third_reviewer": member,
            "decision": decision,
            # Keep legacy scalar fields only for a single-point result. New code
            # must treat final_events as authoritative.
            "final_events": final_events,
            "final_frame_id": final_events[0]["frame_id"] if len(final_events) == 1 else None,
            "final_x": final_events[0]["x"] if len(final_events) == 1 else None,
            "final_y": final_events[0]["y"] if len(final_events) == 1 else None,
            "notes": notes.strip(),
            "blind_review": True,
            "submitted_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "completed": False,
            "completed_at": None,
        }
        if old:
            history = path.parent / "history"
            history.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            atomic_text(history / f"{member}-{record['case_id']}-{stamp}.json", json.dumps(old, ensure_ascii=False, indent=2) + "\n")
            for key in ("edit_count", "last_edit_reason", "reopened_at"):
                if key in old:
                    record[key] = old[key]
        current[record["case_id"]] = record
        order = {str(item["case_id"]): index for index, item in enumerate(self.cases)}
        rows = sorted(current.values(), key=lambda item: order.get(str(item["case_id"]), 10**9))
        atomic_text(path, _jsonl(rows))
        return record

    def delete_confirmed_event(self, member: str, case: dict[str, Any], frame_id: int) -> int:
        """Delete the saved third-review point on one frame; return remaining count."""
        if member != self.assigned_to(case):
            raise ValueError("该争议条目未分配给当前成员")
        current = self.decisions_for(member)
        case_id = str(case["case_id"])
        old = current.get(case_id)
        if not old or old.get("completed") is True:
            raise ValueError("只有未完成的触台判断可以删除；已完成请先按 E 编辑")
        events = _decision_events(old)
        remaining = [item for item in events if int(item["frame_id"]) != int(frame_id)]
        if len(remaining) == len(events):
            raise ValueError("当前帧没有已保存的第三复核球心")

        path = self.decision_path(member)
        history = path.parent / "history"
        history.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        atomic_text(history / f"{member}-{case_id}-{stamp}.json", json.dumps(old, ensure_ascii=False, indent=2) + "\n")
        if remaining:
            record = dict(old)
            record["final_events"] = remaining
            record["final_frame_id"] = remaining[0]["frame_id"] if len(remaining) == 1 else None
            record["final_x"] = remaining[0]["x"] if len(remaining) == 1 else None
            record["final_y"] = remaining[0]["y"] if len(remaining) == 1 else None
            record["submitted_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
            current[case_id] = record
        else:
            del current[case_id]
        order = {str(item["case_id"]): index for index, item in enumerate(self.cases)}
        rows = sorted(current.values(), key=lambda item: order.get(str(item["case_id"]), 10**9))
        atomic_text(path, _jsonl(rows))
        return len(remaining)

    def reopen_decision(self, member: str, case: dict[str, Any], reason: str) -> dict[str, Any]:
        """Back up and unfreeze a completed decision for an audited correction."""
        if member != self.assigned_to(case):
            raise ValueError("该争议条目未分配给当前成员")
        if not reason.strip():
            raise ValueError("重新编辑必须填写原因")
        current = self.decisions_for(member)
        case_id = str(case["case_id"])
        old = current.get(case_id)
        if not old or old.get("completed") is not True:
            raise ValueError("只有已按 C 完成的条目才能重新编辑")

        path = self.decision_path(member)
        history = path.parent / "history"
        history.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        atomic_text(
            history / f"{member}-{case_id}-{stamp}.json",
            json.dumps(old, ensure_ascii=False, indent=2) + "\n",
        )

        record = dict(old)
        record["completed"] = False
        record["completed_at"] = None
        record["edit_count"] = int(old.get("edit_count", 0)) + 1
        record["last_edit_reason"] = reason.strip()
        record["reopened_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        current[case_id] = record
        order = {str(item["case_id"]): index for index, item in enumerate(self.cases)}
        rows = sorted(current.values(), key=lambda item: order.get(str(item["case_id"]), 10**9))
        atomic_text(path, _jsonl(rows))
        return record

    def complete_decision(self, member: str, case: dict[str, Any]) -> dict[str, Any]:
        current = self.decisions_for(member)
        case_id = str(case["case_id"])
        if member != self.assigned_to(case):
            raise ValueError("该争议条目未分配给当前成员")
        if case_id not in current:
            raise ValueError("请先保存触台、不是触台或疑难判断，再按 C 确认完成")
        record = current[case_id]
        if record.get("decision") == "confirmed" and not _decision_events(record):
            raise ValueError("确认触台至少需要保存一个球心")
        record["completed"] = True
        record["completed_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        path = self.decision_path(member)
        order = {str(item["case_id"]): index for index, item in enumerate(self.cases)}
        rows = sorted(current.values(), key=lambda item: order.get(str(item["case_id"]), 10**9))
        atomic_text(path, _jsonl(rows))
        return record


@dataclass
class ReviewResult:
    saved: bool = False
    next_case: bool = False


class AdjudicationViewer:
    MAIN_W, MAIN_H, SIDE_W = 1000, 564, 360
    HEADER, FOOTER = 92, 178
    EDIT_BUTTON = (1018, 704, 1342, 756)

    def __init__(self, project: AdjudicationProject, member: str, case: dict[str, Any], session, annotation):
        self.project, self.member, self.case = project, member, case
        self.session = session
        self.annotation = {item["frame_id"]: item for item in annotation["frames"]}
        self.meta = session.meta
        self.start = max(0, int(case["frame_start"]))
        self.end = min(int(case["frame_end"]), int(self.meta["n_frames"]) - 1)
        candidates = []
        for key in ("initial_only_events", "review_only_events", "initial_uncertain", "review_uncertain"):
            candidates.extend(frame for event in case.get(key, []) if (frame := _event_frame(event)) is not None)
        self.frame_id = min(max(candidates[0] if candidates else (self.start + self.end) // 2, self.start), self.end)
        self.playing = False
        self.show_boxes = True
        self.show_human = False
        self.pending: tuple[float, float] | None = None
        self.zoom = 1.0
        self.zoom_center: tuple[float, float] | None = None
        self.window = f"第三复核 - {case['case_id']}"
        self.message = "能确认触台均标球心（含干扰）；只有无法判断才按 U"
        self.result = ReviewResult()

    def _canvas_transform(self) -> ReviewTransform:
        return ReviewTransform.fit(
            int(self.meta["width"]), int(self.meta["height"]),
            self.MAIN_W, self.MAIN_H, self.zoom, self.zoom_center,
        )

    def _draw_source(self, canvas: np.ndarray, tr: ReviewTransform) -> None:
        image = read_image(Path(self.session.frames_dir) / f"{self.frame_id:06d}.png")
        x0, y0, x1, y1 = tr.source_crop()
        crop = image[y0:y1, x0:x1]
        resized = cv2.resize(crop, (tr.display_w, tr.display_h), interpolation=cv2.INTER_LINEAR)
        canvas[self.HEADER + tr.offset_y:self.HEADER + tr.offset_y + tr.display_h, tr.offset_x:tr.offset_x + tr.display_w] = resized
        if self.show_boxes:
            declared = self.annotation.get(self.frame_id, {})
            for obj in declared.get("annotations", []):
                for bbox in obj.get("bbox_xyxy", []):
                    if not isinstance(bbox, list) or len(bbox) != 4:
                        continue
                    p1 = tr.source_to_display(float(bbox[0]), float(bbox[1]))
                    p2 = tr.source_to_display(float(bbox[2]), float(bbox[3]))
                    cv2.rectangle(canvas, (p1[0], self.HEADER + p1[1]), (p2[0], self.HEADER + p2[1]), (70, 220, 110), 1)
        if self.pending:
            px, py = tr.source_to_display(*self.pending)
            cv2.drawMarker(canvas, (px, self.HEADER + py), (255, 80, 255), cv2.MARKER_CROSS, 16, 2)

    def _human_events(self):
        for key, color, label in (
            ("initial_only_events", (255, 170, 30), "初标"),
            ("review_only_events", (60, 80, 255), "复核"),
            ("initial_uncertain", (255, 100, 220), "初标疑难"),
            ("review_uncertain", (180, 80, 255), "复核疑难"),
        ):
            for event in self.case.get(key, []):
                yield event, color, label

    def _draw_human(self, canvas: np.ndarray, tr: ReviewTransform) -> None:
        if self.show_human:
            for event, color, _label in self._human_events():
                if (_event_frame(event) == self.frame_id
                        and isinstance(event.get("x"), (int, float))
                        and isinstance(event.get("y"), (int, float))):
                    px, py = tr.source_to_display(float(event["x"]), float(event["y"]))
                    point = (px, self.HEADER + py)
                    cv2.drawMarker(canvas, point, color, cv2.MARKER_CROSS, 22, 2)
        own = self.project.decisions_for(self.member).get(str(self.case["case_id"]))
        for event in _decision_events(own):
            if int(event["frame_id"]) != self.frame_id:
                continue
            px, py = tr.source_to_display(float(event["x"]), float(event["y"]))
            point = (px, self.HEADER + py)
            # Match the initial-annotation interaction: a click is a temporary
            # crosshair, while an Enter-saved center is a blue circle.
            cv2.circle(canvas, point, 8, (255, 150, 0), 2)

    def render(self) -> np.ndarray:
        h = self.HEADER + self.MAIN_H + self.FOOTER
        canvas = np.full((h, self.MAIN_W + self.SIDE_W, 3), (24, 27, 34), np.uint8)
        tr = self._canvas_transform()
        self._draw_source(canvas, tr)
        self._draw_human(canvas, tr)
        bar_y = self.HEADER + self.MAIN_H
        cv2.rectangle(canvas, (0, bar_y), (self.MAIN_W, h), (36, 40, 49), -1)
        labels: list[tuple[str, tuple[int, int], int, tuple[int, int, int], bool]] = []
        def add(content, position, size=17, color=(220, 225, 235), bold=False):
            labels.append((str(content), position, size, color, bold))
        add(f"第三复核（{self.member}）  {self.case['case_id']}", (22, 14), 27, (245, 245, 245), True)
        add(f"原视频帧 {self.frame_id}   争议范围 {self.start}-{self.end}", (22, 53), 20, (180, 205, 240))
        x = self.MAIN_W + 18
        add("独立裁决", (x, 18), 25, (255, 255, 255), True)
        add(f"视频: {self.case['video_id']}", (x, 62), 19, (220, 220, 220))
        add(f"初标/复核: {self.case['initial_annotator']} / {self.case['reviewer']}", (x, 92), 19, (220, 220, 220))
        status = self.project.status(self.member, self.case)
        add(f"状态: {status}", (x, 126), 20, (100, 230, 150) if status != "pending" else (80, 190, 255), True)
        own = self.project.decisions_for(self.member).get(str(self.case["case_id"]))
        add(f"已保存触台点: {len(_decision_events(own))}", (x, 154), 18, (180, 205, 240))
        lines = [
            "左键  标记球心", "Enter 保存触台（含干扰）", "X     保存不是触台", "U     保存纯疑难及原因",
            "C     确认本条完成", "A/D   前/后一帧", "空格   播放/暂停", "0     从争议段开头播放",
            "G     跳转原视频帧", "B     检测框开关", "Z     局部放大/还原", "Delete 删除当前帧球心",
            "H     完成后对照双方", "E     完成后重新编辑", "N     下一条", "Esc   返回列表",
        ]
        if self.show_human:
            lines = [
                "H     隐藏双方对照", "E     重新编辑", "A/D   前/后一帧", "B     检测框开关", "N     下一条",
                "", "只显示当前帧上的球心", "蓝色十字：初标", "红色十字：复核",
                "蓝色圆圈：第三复核已保存",
            ]
        yy = 184
        for line in lines:
            add(line, (x, yy), 17, (205, 210, 220))
            yy += 27
        completed = status not in {"pending", "in_progress"}
        bx0, by0, bx1, by1 = self.EDIT_BUTTON
        button_color = (54, 116, 82) if completed else (55, 58, 66)
        cv2.rectangle(canvas, (bx0, by0), (bx1, by1), button_color, -1)
        cv2.rectangle(canvas, (bx0, by0), (bx1, by1), (105, 220, 155) if completed else (95, 98, 108), 2)
        add("完成后编辑（E）" if completed else "完成后可编辑（E）", (bx0 + 61, by0 + 13), 20,
            (245, 250, 245) if completed else (145, 148, 158), True)
        add(self.message, (20, bar_y + 18), 19, (120, 220, 255))
        add("Enter 触台（含干扰）  X 非触台  U 疑难  C 完成  E 编辑  H 对照", (20, bar_y + 60), 22, (245, 245, 245), True)
        add("紫色十字为待保存准星；Enter 后变为蓝色圆圈。", (20, bar_y + 105), 18, (190, 195, 205))
        return _paint_texts(canvas, labels)

    def _ask_text(self, prompt: str) -> str | None:
        from gui_dialogs import ask
        return ask("第三复核", prompt)

    def _confirm(self, prompt: str) -> bool:
        from gui_dialogs import ask
        return bool(ask("确认提交", prompt, confirm=True))

    def _save(self, decision: str) -> None:
        if self.project.status(self.member, self.case) not in {"pending", "in_progress"}:
            self.message = "本条已经按 C 完成，记录已冻结"
            return
        notes = ""
        if decision == "confirmed":
            if self.pending is None:
                self.message = "请先在球心位置点击，再按 Enter"
                return
            x, y = self.pending
            record = self.project.save_decision(self.member, self.case, decision, self.frame_id, x, y)
        elif decision == "no_bounce":
            if not self._confirm("确认该争议片段没有触台事件？"):
                return
            self.project.save_decision(self.member, self.case, decision)
        else:
            value = self._ask_text("只有确实无法判断是否触台时才标疑难。请输入原因（不能为空）：")
            if value is None:
                return
            try:
                self.project.save_decision(self.member, self.case, decision, notes=value)
            except ValueError as exc:
                self.message = str(exc)
                return
        self.result.saved = True
        self.show_human = False
        self.pending = None
        count = len(_decision_events(record)) if decision == "confirmed" else 0
        self.message = (f"已保存触台点，共 {count} 个；可继续换帧添加，完成后按 C"
                        if decision == "confirmed"
                        else "判断已保存但尚未完成；请核对后按 C 确认本条完成")

    def _delete_current_event(self) -> None:
        try:
            remaining = self.project.delete_confirmed_event(self.member, self.case, self.frame_id)
        except ValueError as exc:
            self.message = str(exc)
            return
        self.pending = None
        self.result.saved = True
        self.message = (f"已删除当前帧球心，还剩 {remaining} 个"
                        if remaining else "最后一个球心已删除；请重新标记或选择其他判断")

    def _reopen(self) -> None:
        status = self.project.status(self.member, self.case)
        if status in {"pending", "in_progress"}:
            self.message = "只有已按 C 完成的条目才能重新编辑"
            return
        reason = self._ask_text("请输入重新编辑原因（不能为空）：")
        if reason is None:
            return
        try:
            record = self.project.reopen_decision(self.member, self.case, reason)
        except ValueError as exc:
            self.message = str(exc)
            return
        self.playing = False
        self.show_human = False
        events = _decision_events(record)
        if events:
            self.frame_id = int(events[0]["frame_id"])
            self.pending = (float(events[0]["x"]), float(events[0]["y"]))
        else:
            self.pending = None
        self.result.saved = True
        self.message = "已解冻并保留旧版历史；修改判断后请重新按 C 完成"

    def on_mouse(self, event, x, y, flags, param) -> None:
        if event != cv2.EVENT_LBUTTONDOWN:
            return
        bx0, by0, bx1, by1 = self.EDIT_BUTTON
        if bx0 <= x <= bx1 and by0 <= y <= by1:
            self._reopen()
            return
        if x >= self.MAIN_W or y < self.HEADER or y >= self.HEADER + self.MAIN_H:
            return
        tr = self._canvas_transform()
        point = tr.display_to_source(x, y - self.HEADER)
        if point is not None:
            self.playing = False
            self.pending = point
            self.message = f"已标记球心 ({point[0]:.1f}, {point[1]:.1f})；已暂停，按 Enter 提交"

    def run(self) -> ReviewResult:
        # Fixed image pixels avoid cursor drift under Windows DPI scaling.
        cv2.namedWindow(self.window, cv2.WINDOW_AUTOSIZE)
        cv2.setMouseCallback(self.window, self.on_mouse)
        last_tick = time.monotonic()
        while True:
            cv2.imshow(self.window, self.render())
            # Poll in both playing and paused states. A blocking waitKey(0) prevents
            # mouse-only changes from being repainted and ignores the title-bar X.
            key = cv2.waitKeyEx(25)
            if cv2.getWindowProperty(self.window, cv2.WND_PROP_VISIBLE) < 1:
                break
            if self.playing:
                now = time.monotonic()
                if now - last_tick >= 1.0 / max(float(self.meta.get("fps", 25.0)), 1.0):
                    self.frame_id = self.start if self.frame_id >= self.end else self.frame_id + 1
                    self.pending = None
                    last_tick = now
            if key in (-1, 255):
                continue
            if key in (27, ord("q"), ord("Q")):
                break
            if key in (ord("a"), ord("A"), 2424832):
                self.frame_id = max(self.start, self.frame_id - 1); self.playing = False; self.pending = None
            elif key in (ord("d"), ord("D"), 2555904):
                self.frame_id = min(self.end, self.frame_id + 1); self.playing = False; self.pending = None
            elif key == 32:
                self.playing = not self.playing; last_tick = time.monotonic()
            elif key == ord("0"):
                self.frame_id = self.start; self.playing = True; self.pending = None; last_tick = time.monotonic()
            elif key in (ord("b"), ord("B")):
                self.show_boxes = not self.show_boxes
            elif key in (ord("z"), ord("Z")):
                if self.zoom == 1.0:
                    self.zoom = 2.5
                    self.zoom_center = self.pending or (float(self.meta["width"]) / 2, float(self.meta["height"]) / 2)
                else:
                    self.zoom = 1.0; self.zoom_center = None
            elif key in (ord("g"), ord("G")):
                value = self._ask_text(f"输入原视频帧号（本条范围 {self.start}-{self.end}）：")
                if value is not None:
                    try:
                        frame = int(value)
                        if not self.start <= frame <= self.end:
                            raise ValueError
                        self.frame_id = frame; self.playing = False; self.pending = None
                    except ValueError:
                        self.message = "帧号必须在当前争议范围内"
            elif key in (13, 10):
                self._save("confirmed")
            elif key in (ord("x"), ord("X")):
                self._save("no_bounce")
            elif key in (ord("u"), ord("U")):
                self._save("uncertain")
            elif key in (8, 127, 3014656):
                self._delete_current_event()
            elif key in (ord("e"), ord("E")):
                self._reopen()
            elif key in (ord("c"), ord("C")):
                status = self.project.status(self.member, self.case)
                if status == "pending":
                    self.message = "请先保存触台、不是触台或疑难判断，再按 C 完成"
                elif status != "in_progress":
                    self.message = "本条已经确认完成；按 H 对照、E 重新编辑，或 N 下一条"
                elif self._confirm("确认已完整检查本争议片段，并完成当前判断？"):
                    self.project.complete_decision(self.member, self.case)
                    self.result.saved = True
                    self.show_human = False
                    self.message = "本条已完成并冻结；按 H 对照、E 重新编辑，或 N 下一条"
            elif key in (ord("h"), ord("H")):
                if self.project.status(self.member, self.case) in {"pending", "in_progress"}:
                    self.message = "为避免受双方判断影响，请先保存判断并按 C 确认完成"
                else:
                    self.show_human = not self.show_human
                    self.message = "已显示对照；只显示当前帧实际存在的球心" if self.show_human else "已隐藏双方标签"
            elif key in (ord("n"), ord("N")):
                if self.project.status(self.member, self.case) in {"pending", "in_progress"}:
                    self.message = "本条尚未按 C 完成；请先确认完成，或按 Esc 返回列表"
                else:
                    self.result.next_case = True
                    break
        try:
            cv2.destroyWindow(self.window)
        except cv2.error:
            pass  # The title-bar X may already have destroyed it.
        return self.result


class AdjudicationWindow:
    WIDTH, HEIGHT = 1160, 800

    def __init__(self, project: AdjudicationProject, member: str):
        self.project, self.member = project, member
        self.cases = project.cases_for(member)
        self.selected = 0
        self.scroll = 0
        self.window = f"第三复核任务 - 成员 {member}"
        self.message = "双击争议条目，或按 Enter 打开原视频"

    def render(self) -> np.ndarray:
        canvas = np.full((self.HEIGHT, self.WIDTH, 3), (24, 27, 34), np.uint8)
        decisions = self.project.decisions_for(self.member)
        done = sum(decisions.get(str(case["case_id"]), {}).get("completed") is True for case in self.cases)
        labels: list[tuple[str, tuple[int, int], int, tuple[int, int, int], bool]] = []
        def add(content, position, size=17, color=(220, 225, 235), bold=False):
            labels.append((str(content), position, size, color, bold))
        add(f"第三复核 / 裁决 — 成员 {self.member}", (28, 20), 30, (245, 245, 245), True)
        add(f"已完成 {done}/{len(self.cases)}；系统只分配你未参与初标和复核的争议条目", (28, 63), 20, (150, 215, 255))
        add("序号   状态          case_id                 视频       初标→复核     原视频帧范围", (28, 112), 18, (180, 185, 200), True)
        row_h, top, visible = 42, 148, 13
        self.scroll = min(max(self.scroll, 0), max(0, len(self.cases) - visible))
        for line, index in enumerate(range(self.scroll, min(len(self.cases), self.scroll + visible))):
            case = self.cases[index]
            y = top + line * row_h
            if index == self.selected:
                cv2.rectangle(canvas, (20, y - 5), (1138, y + 31), (55, 68, 88), -1)
            record = decisions.get(str(case["case_id"]), {})
            status = (record.get("decision", "pending") if record.get("completed") is True
                      else "in_progress" if record else "pending")
            color = ((90, 225, 145) if record.get("completed") is True
                     else (100, 210, 255) if record else (80, 190, 255))
            line_text = f"{index + 1:>3}    {status:<13} {str(case['case_id']):<23} {str(case['video_id']):<10} {case['initial_annotator']} → {case['reviewer']}        {case['frame_start']}-{case['frame_end']}"
            add(line_text, (30, y), 18, color)
        cv2.rectangle(canvas, (20, 714), (1138, 780), (36, 40, 49), -1)
        add(self.message, (34, 727), 18, (120, 220, 255))
        add("滚轮/↑/↓ 选择   Enter 打开   R 刷新   Esc 返回主界面", (34, 756), 18, (225, 225, 230))
        return _paint_texts(canvas, labels)

    def _ensure_visible(self) -> None:
        if self.selected < self.scroll:
            self.scroll = self.selected
        elif self.selected >= self.scroll + 13:
            self.scroll = self.selected - 12

    @staticmethod
    def _wheel_delta(flags: int) -> int:
        """Decode OpenCV's signed Windows wheel delta from the high word."""
        value = (int(flags) >> 16) & 0xFFFF
        return value - 0x10000 if value >= 0x8000 else value

    def on_mouse(self, event, x, y, flags, param) -> None:
        if event == cv2.EVENT_MOUSEWHEEL and self.cases:
            delta = self._wheel_delta(flags)
            if delta:
                step = -3 if delta > 0 else 3
                self.selected = min(len(self.cases) - 1, max(0, self.selected + step))
                self._ensure_visible()
                self.message = f"已选择第 {self.selected + 1}/{len(self.cases)} 条；双击或按 Enter 打开"
            return
        if 143 <= y < 143 + 13 * 42:
            index = self.scroll + (y - 143) // 42
            if 0 <= index < len(self.cases):
                self.selected = index
                if event == cv2.EVENT_LBUTTONDBLCLK:
                    self.open_selected()

    def open_selected(self) -> None:
        if not self.cases:
            self.message = "当前成员没有分配到争议条目"
            return
        case = self.cases[self.selected]
        self.message = f"正在准备 {case['case_id']} 的原视频，首次打开会提取帧……"
        cv2.imshow(self.window, self.render()); cv2.waitKey(1)
        try:
            session, annotation = self.project.prepare_case(case)
            cv2.destroyWindow(self.window)
            result = AdjudicationViewer(self.project, self.member, case, session, annotation).run()
            if result.next_case and self.selected + 1 < len(self.cases):
                self.selected += 1
            self.message = "裁决已保存到 third_review；原 initial/review 未修改" if result.saved else "已返回任务列表"
            cv2.namedWindow(self.window, cv2.WINDOW_AUTOSIZE)
            cv2.setMouseCallback(self.window, self.on_mouse)
        except Exception as exc:
            self.message = f"打开失败: {exc}"

    def run(self) -> None:
        cv2.namedWindow(self.window, cv2.WINDOW_AUTOSIZE)
        cv2.setMouseCallback(self.window, self.on_mouse)
        while True:
            cv2.imshow(self.window, self.render())
            key = cv2.waitKeyEx(30)
            if cv2.getWindowProperty(self.window, cv2.WND_PROP_VISIBLE) < 1:
                break
            if key in (27, ord("q"), ord("Q")):
                break
            if key in (2490368, ord("w"), ord("W")):
                self.selected = max(0, self.selected - 1); self._ensure_visible()
            elif key in (2621440, ord("s"), ord("S")):
                self.selected = min(max(0, len(self.cases) - 1), self.selected + 1); self._ensure_visible()
            elif key in (13, 10):
                self.open_selected()
            elif key in (ord("r"), ord("R")):
                self.message = "状态已刷新"
        try:
            cv2.destroyWindow(self.window)
        except cv2.error:
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description="第三人盲审裁决工具")
    parser.add_argument("--package", required=True, type=Path, help="包含 decision_template.jsonl 的裁决包")
    parser.add_argument("--data-root", required=True, type=Path, help="同时包含 A/B/C/D 的原始数据目录")
    parser.add_argument("--member", required=True, choices=MEMBERS)
    parser.add_argument("--summary", action="store_true", help="只打印分配统计，不打开界面")
    args = parser.parse_args()
    project = AdjudicationProject(args.package, args.data_root)
    if args.summary:
        summary = {member: len(project.cases_for(member)) for member in MEMBERS}
        print(json.dumps({"cases": len(project.cases), "assignments": summary}, ensure_ascii=False))
        return 0
    AdjudicationWindow(project, args.member).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
