param(
    [ValidateSet('resume', 'initial', 'selfcheck')]
    [string]$Round = 'resume'
)
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$taskPython = Join-Path $taskRoot '.venv-annotation\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $taskPython)) {
    throw 'Annotation environment missing. See development/annotation/README.md.'
}
$taskScript = Join-Path $PSScriptRoot 'annotate.py'
if ($Round -eq 'resume') {
    $taskLocalScript = Join-Path $PSScriptRoot 'local_annotation.py'
    & $taskPython $taskLocalScript
} else {
    & $taskPython $taskScript --round $Round
}
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Annotation stopped. Read the diagnostic above; existing labels are preserved.'
    Read-Host 'Press Enter to close'
}
