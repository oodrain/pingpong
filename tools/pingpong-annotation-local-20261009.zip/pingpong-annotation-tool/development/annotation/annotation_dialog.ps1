param(
    [ValidateSet('text', 'integer', 'confirm', 'file', 'folder')][string]$Kind = 'text',
    [string]$DialogTitle = '',
    [string]$Prompt = '',
    [string]$Initial = '',
    [int]$Minimum = 0,
    [int]$Maximum = 0,
    [string]$FileFilter = 'All files|*.*',
    [switch]$SmokeTest
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

if ($Kind -eq 'file' -or $Kind -eq 'folder') {
    if ($SmokeTest) {
        @{ ok = $false; value = $null } | ConvertTo-Json -Compress
        exit 0
    }
    if ($Kind -eq 'file') {
        $taskPicker = New-Object System.Windows.Forms.OpenFileDialog
        $taskPicker.Title = $DialogTitle
        $taskPicker.Filter = $FileFilter
        $taskPicker.CheckFileExists = $true
        if ($Initial -and (Test-Path -LiteralPath $Initial -PathType Container)) { $taskPicker.InitialDirectory = $Initial }
    } else {
        $taskPicker = New-Object System.Windows.Forms.FolderBrowserDialog
        $taskPicker.Description = $DialogTitle
        $taskPicker.ShowNewFolderButton = $true
        if ($Initial -and (Test-Path -LiteralPath $Initial -PathType Container)) { $taskPicker.SelectedPath = $Initial }
    }
    $taskPickerOwner = New-Object System.Windows.Forms.Form
    $taskPickerOwner.TopMost = $true
    $taskPickerOwner.ShowInTaskbar = $false
    $taskPickerOwner.Opacity = 0
    $taskPickerOwner.Size = New-Object System.Drawing.Size(1, 1)
    $taskPickerOwner.StartPosition = 'CenterScreen'
    $taskPickerOwner.Show()
    try { $taskPickerResult = $taskPicker.ShowDialog($taskPickerOwner) }
    finally { $taskPickerOwner.Dispose() }
    $taskPickerValue = $null
    if ($taskPickerResult -eq [System.Windows.Forms.DialogResult]::OK) {
        if ($Kind -eq 'file') { $taskPickerValue = $taskPicker.FileName }
        else { $taskPickerValue = $taskPicker.SelectedPath }
    }
    $taskPicker.Dispose()
    @{ ok = ($taskPickerResult -eq [System.Windows.Forms.DialogResult]::OK); value = $taskPickerValue } | ConvertTo-Json -Compress
    exit 0
}

$taskForm = New-Object System.Windows.Forms.Form
$taskForm.Text = $DialogTitle
$taskForm.ClientSize = New-Object System.Drawing.Size(560, 200)
$taskForm.StartPosition = 'CenterScreen'
$taskForm.FormBorderStyle = 'FixedDialog'
$taskForm.MaximizeBox = $false
$taskForm.MinimizeBox = $false
$taskForm.TopMost = $true

$taskLabel = New-Object System.Windows.Forms.Label
$taskLabel.Text = $Prompt
$taskLabel.Location = New-Object System.Drawing.Point(16, 16)
$taskLabel.Size = New-Object System.Drawing.Size(528, 65)
$taskForm.Controls.Add($taskLabel)

$taskInput = New-Object System.Windows.Forms.TextBox
$taskInput.Text = $Initial
$taskInput.Location = New-Object System.Drawing.Point(16, 84)
$taskInput.Size = New-Object System.Drawing.Size(528, 25)
$taskInput.Visible = ($Kind -ne 'confirm')
$taskForm.Controls.Add($taskInput)

$taskOk = New-Object System.Windows.Forms.Button
$taskOk.Text = 'OK'
$taskOk.Location = New-Object System.Drawing.Point(342, 140)
$taskOk.Size = New-Object System.Drawing.Size(95, 32)
$taskCancel = New-Object System.Windows.Forms.Button
$taskCancel.Text = 'Cancel'
$taskCancel.Location = New-Object System.Drawing.Point(449, 140)
$taskCancel.Size = New-Object System.Drawing.Size(95, 32)
$taskCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$taskForm.Controls.AddRange(@($taskOk, $taskCancel))
$taskForm.AcceptButton = $taskOk
$taskForm.CancelButton = $taskCancel

# Export reports and file details can be much longer than a short annotation prompt.
if ($Prompt.Length -gt 160 -or ($Prompt -split "`n").Count -gt 3) {
    $taskForm.ClientSize = New-Object System.Drawing.Size(760, 480)
    $taskLabel.Visible = $false
    $taskPromptBox = New-Object System.Windows.Forms.TextBox
    $taskPromptBox.Text = $Prompt
    $taskPromptBox.Multiline = $true
    $taskPromptBox.ReadOnly = $true
    $taskPromptBox.ScrollBars = 'Vertical'
    $taskPromptBox.Location = New-Object System.Drawing.Point(16, 16)
    $taskPromptBox.Size = New-Object System.Drawing.Size(728, 330)
    $taskForm.Controls.Add($taskPromptBox)
    $taskInput.Location = New-Object System.Drawing.Point(16, 355)
    $taskInput.Size = New-Object System.Drawing.Size(728, 25)
    $taskOk.Location = New-Object System.Drawing.Point(526, 420)
    $taskCancel.Location = New-Object System.Drawing.Point(633, 420)
}

$taskOk.Add_Click({
    if ($Kind -eq 'integer') {
        $taskNumber = 0
        if (-not [int]::TryParse($taskInput.Text, [ref]$taskNumber) -or $taskNumber -lt $Minimum -or $taskNumber -gt $Maximum) {
            [System.Windows.Forms.MessageBox]::Show("Enter an integer between $Minimum and $Maximum.", 'Invalid value') | Out-Null
            return
        }
    }
    $taskForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $taskForm.Close()
})
$taskForm.Add_Shown({ $taskInput.SelectAll(); $taskInput.Focus() })
if ($SmokeTest) {
    $taskTimer = New-Object System.Windows.Forms.Timer
    $taskTimer.Interval = 1200
    $taskTimer.Add_Tick({ $taskTimer.Stop(); $taskForm.DialogResult = [System.Windows.Forms.DialogResult]::Cancel; $taskForm.Close() })
    $taskTimer.Start()
}
$taskResult = $taskForm.ShowDialog()
$taskValue = $null
if ($taskResult -eq [System.Windows.Forms.DialogResult]::OK) {
    if ($Kind -eq 'confirm') { $taskValue = $true }
    elseif ($Kind -eq 'integer') { $taskValue = [int]$taskInput.Text }
    else { $taskValue = $taskInput.Text }
}
$taskResponse = @{ ok = ($taskResult -eq [System.Windows.Forms.DialogResult]::OK); value = $taskValue }
$taskForm.Dispose()
$taskResponse | ConvertTo-Json -Compress
