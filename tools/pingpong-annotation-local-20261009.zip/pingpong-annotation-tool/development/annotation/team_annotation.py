"""Local team task window, independent review workspaces and portable task index."""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import re
import sys
from pathlib import Path

import cv2

from annotation_core import PROJECT, OutputLock, Session, prepare, read_json, write_json

DEFAULT_TASKS = PROJECT / "development/annotation/tasks.json"
DEFAULT_TEAM = PROJECT / "outputs/team_annotation"
MEMBERS = ("A", "B", "C", "D")
REVIEWER = {"A": "B", "B": "C", "C": "D", "D": "A"}


def safe_id(value):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", value):
        raise ValueError("视频编号/成员只能含字母、数字、下划线和短横线。")
    return value


def generate_tasks(path=DEFAULT_TASKS, data_root=None):
    path = Path(path)
    if path.exists():
        raise ValueError("任务清单已存在，保留现有分配；需要改分工可编辑清单。")
    data_root = Path(data_root or PROJECT / "pp_train_data/pp_train_data")
    tasks = []
    for annotation in sorted((data_root / "annotations").rglob("*.json")):
        data = read_json(annotation)
        video = data_root / data["video_path"]
        if not video.is_file():
            raise ValueError(f"缺少训练视频：{video}")
        task = {"video_id": safe_id(data["video_id"]),
                "video": str(video.resolve().relative_to(PROJECT.resolve())).replace("\\", "/"),
                "annotation": str(annotation.resolve().relative_to(PROJECT.resolve())).replace("\\", "/"),
                "n_frames_declared": data["num_frames"], "source_group": "unknown",
                "split": "unassigned", "annotator": "", "reviewer": ""}
        tasks.append(task)
    if not tasks:
        raise ValueError("没有找到训练JSON，请核对数据目录。")
    if len({t["video_id"] for t in tasks}) != len(tasks):
        raise ValueError("视频编号重复，不能生成任务清单。")
    quotas = {m: len(tasks) // 4 + (i < len(tasks) % 4) for i, m in enumerate(MEMBERS)}
    counts, frames = {m: 0 for m in MEMBERS}, {m: 0 for m in MEMBERS}
    # Approximate frame-balanced allocation with exact per-person clip quotas.
    order = sorted(tasks, key=lambda t: (t["video_id"] != "03_007", -t["n_frames_declared"], t["video_id"]))
    for task in order:
        member = "A" if task["video_id"] == "03_007" else min(
            (m for m in MEMBERS if counts[m] < quotas[m]), key=lambda m: (frames[m], counts[m], m))
        task["annotator"], task["reviewer"] = member, REVIEWER[member]
        counts[member] += 1
        frames[member] += task["n_frames_declared"]
    write_json(path, {"schema_version": 1, "path_base": "project_root", "tasks": tasks})
    return tasks


def load_tasks(path=DEFAULT_TASKS):
    path = Path(path)
    if not path.exists():
        generate_tasks(path)
    tasks = read_json(path)["tasks"]
    seen = set()
    for task in tasks:
        vid = safe_id(task["video_id"])
        if vid in seen:
            raise ValueError("任务清单有重复视频编号。")
        seen.add(vid)
        if task["annotator"] not in MEMBERS or task["reviewer"] not in MEMBERS:
            raise ValueError("成员需为A/B/C/D。")
        if task["annotator"] == task["reviewer"]:
            raise ValueError("初标与交叉复核不能是同一成员。")
    return tasks


def task_paths(task, member, output_root=DEFAULT_TEAM):
    workspace = Path(output_root) / safe_id(member) / safe_id(task["video_id"])
    frames = Path(output_root) / "_frames" / task["video_id"]
    return workspace, frames


def initial_snapshot(state):
    return {"inputs": {k: state["inputs"][k] for k in ("video_sha256", "annotation_sha256")},
            "video": state["video"], "events": state["events"]["initial"],
            "progress": state["rounds"]["initial"],
            "uncertain": [e for e in state["uncertain"] if e["round"] == "initial"],
            "non_table": [e for e in state.get("non_table", []) if e.get("round", "initial") == "initial"]}


def snapshot_hash(snapshot):
    identity = copy.deepcopy(snapshot)
    # Merely browsing a frozen initial session does not invalidate a review.
    identity["progress"].pop("current_frame", None)
    identity["progress"].pop("window_seconds", None)
    return hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def import_pilot(task, member, output_root=DEFAULT_TEAM):
    """Explicit opt-in copy; the original pilot and its authorship remain untouched."""
    if task["video_id"] != "03_007" or member != task["annotator"]:
        raise ValueError("旧试点只能导入03_007初标责任人的工作副本。")
    source = PROJECT / "outputs/annotation_pilot/03_007/session.json"
    workspace, _ = task_paths(task, member, output_root)
    if (workspace / "session.json").exists():
        raise ValueError("团队工作副本已存在，不覆盖。")
    original = read_json(source)
    Session(source.parent, original)
    interference = source.parent / "non_table_events.jsonl"
    if interference.exists() and not original["non_table"]:
        for line in interference.read_text(encoding="utf-8-sig").splitlines():
            if line.strip():
                record = json.loads(line)
                record.setdefault("round", "initial")
                original["non_table"].append(record)
    original["current_round"] = "initial"
    original["participants"]["initial"] = member
    original["imported_from"] = {"path": str(source), "note": "接管个人试点，未改变原始作者/判断来源"}
    with OutputLock(workspace):
        write_json(workspace / "session.json", original)


def prepare_task(task, member, phase, output_root=DEFAULT_TEAM):
    workspace, frames = task_paths(task, member, output_root)
    if phase not in ("initial", "review"):
        raise ValueError("请选择初标或交叉复核。")
    if member != task["annotator" if phase == "initial" else "reviewer"]:
        raise ValueError("当前任务没有分配给该成员。")
    if read_json(PROJECT / task["annotation"])["video_id"] != task["video_id"]:
        raise ValueError("任务编号与对象JSON不一致，不创建工作副本。")
    source_snapshot, source_path = None, None
    if phase == "review":
        source_path = task_paths(task, task["annotator"], output_root)[0] / "session.json"
        if not source_path.exists():
            raise ValueError("初标尚未开始；先同步初标者的session和标签工作目录。")
        source = read_json(source_path)
        Session(source_path.parent, source)
        if source["participants"].get("initial") != task["annotator"]:
            raise ValueError("初标成员与任务分配不同，请核对来源和分工。")
        if source["rounds"]["initial"]["completed_at"] is None:
            raise ValueError("初标尚未完成，暂不开始交叉复核。")
        source_snapshot = initial_snapshot(source)
    session, annotation = prepare(PROJECT / task["video"], PROJECT / task["annotation"],
                                  workspace, frames_dir=frames)
    prior_member = session.state["participants"].get(phase)
    if prior_member and prior_member != member:
        raise ValueError("工作副本已有其他成员记录，请使用独立目录。")
    if annotation["video_id"] != task["video_id"]:
        raise ValueError("任务编号与对象JSON不一致。")
    if source_snapshot:
        for key in ("video_sha256", "annotation_sha256"):
            if source_snapshot["inputs"][key] != session.state["inputs"][key]:
                raise ValueError("初标与复核输入哈希不同，暂停对照。")
        digest = snapshot_hash(source_snapshot)
        prior = session.state.get("review_source")
        if prior and prior["snapshot_sha256"] != digest:
            raise ValueError("初标已修改，现有复核保留；请使用新的团队输出目录重新复核。")
        if prior is None:
            session.state["events"]["initial"] = copy.deepcopy(source_snapshot["events"])
            session.state["rounds"]["initial"] = copy.deepcopy(source_snapshot["progress"])
            session.state["uncertain"] = copy.deepcopy(source_snapshot["uncertain"])
            session.state["non_table"] = copy.deepcopy(source_snapshot["non_table"])
            session.state["review_source"] = {"path": str(source_path), "snapshot_sha256": digest}
        session.state["participants"].update(initial=task["annotator"], review=member)
    else:
        session.state["participants"]["initial"] = member
    session.switch_round(phase)
    session.save()
    return session, annotation


def task_status(task, phase, output_root=DEFAULT_TEAM):
    member = task["annotator" if phase == "initial" else "reviewer"]
    path = task_paths(task, member, output_root)[0] / "session.json"
    if not path.exists():
        if phase == "review":
            source = task_paths(task, task["annotator"], output_root)[0] / "session.json"
            if not source.exists() or read_json(source)["rounds"]["initial"]["completed_at"] is None:
                return "待初标", 0, 0
        return "待开始", 0, 0
    state = read_json(path)
    p = state["rounds"].get(phase, {})
    status = "已完成" if p.get("completed_at") is not None else "进行中"
    return status, len(p.get("seen_frames", [])), len(state["events"].get(phase, []))


def export_summary(tasks, output_root=DEFAULT_TEAM):
    path = Path(output_root) / "progress.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["video_id", "annotator", "reviewer", "declared_frames", "source_group", "split",
                         "initial_status", "initial_seen", "initial_events", "review_status", "review_seen", "review_events"])
        for task in sorted(tasks, key=lambda t: (t["video_id"] != "03_007", t["video_id"])):
            writer.writerow([task["video_id"], task["annotator"], task["reviewer"], task["n_frames_declared"],
                             task.get("source_group", "unknown"), task.get("split", "unassigned"),
                             *task_status(task, "initial", output_root), *task_status(task, "review", output_root)])
    return path


def launch(tasks, output_root=DEFAULT_TEAM, *, smoke_test=False, preview_path=None):
    """OpenCV task window shares the same runtime as the video viewer."""
    import time
    import numpy as np
    from PIL import Image, ImageDraw
    from annotate import Viewer, font
    from annotation_core import write_image
    from gui_dialogs import ask

    title = "Pingpong Team Tasks"
    member, phase, query = "A", "initial", ""
    selected, scroll, pending = None, 0, None
    message = "选择成员和阶段，双击视频打开；先用少量片段统一标注口径。"
    rows, visible = [], []
    row_height, capacity = 27, 14

    def refresh():
        nonlocal visible, scroll, selected
        visible = [task for task in sorted(tasks, key=lambda t: (t["video_id"] != "03_007", t["video_id"]))
                   if task["annotator" if phase == "initial" else "reviewer"] == member
                   and query.lower() in task["video_id"].lower()]
        scroll = max(0, min(scroll, max(0, len(visible) - capacity)))
        if selected not in [t["video_id"] for t in visible]:
            selected = visible[0]["video_id"] if visible else None

    def draw():
        nonlocal rows
        image = Image.new("RGB", (960, 650), (24, 28, 35))
        paint = ImageDraw.Draw(image)
        def label(x, y, value, size=17, color=(225, 229, 237)):
            paint.text((x, y), value, font=font(size), fill=color)
        def button(box, text, active=False):
            paint.rectangle(box, fill=(52, 90, 125) if active else (45, 51, 62))
            label(box[0]+10, box[1]+8, text)
        label(15, 12, "乒乓球小组标注任务", 25)
        for i, name in enumerate(MEMBERS):
            button((15+i*64, 55, 70+i*64, 93), name, member == name)
        button((295, 55, 395, 93), "初标", phase == "initial")
        button((410, 55, 535, 93), "交叉复核", phase == "review")
        button((565, 55, 740, 93), "筛选视频编号")
        label(755, 66, query or "全部任务")
        label(15, 110, "1—4选成员 · Tab切换阶段 · 滚轮/上下键选视频 · Enter打开 · Q退出")
        paint.rectangle((12, 145, 945, 177), fill=(39, 45, 55))
        for x, name in zip((25, 220, 330, 440, 550, 730, 850),
                           ("视频", "声明帧数", "初标", "复核", "本阶段状态", "已查看", "触台")):
            label(x, 150, name)
        rows = []
        for index, task in enumerate(visible[scroll:scroll+capacity]):
            top = 180 + index*row_height
            if task["video_id"] == selected:
                paint.rectangle((12, top, 945, top+row_height-1), fill=(43, 65, 85))
            status, seen, events = task_status(task, phase, output_root)
            for x, value in zip((25, 220, 330, 440, 550, 730, 850),
                                (task["video_id"], task["n_frames_declared"], task["annotator"], task["reviewer"], status, seen, events)):
                label(x, top+3, str(value), 16)
            rows.append((top, top+row_height, task["video_id"]))
        label(15, 565, f"成员 {member} · {'初标' if phase=='initial' else '交叉复核'} · 共{len(visible)}段 · 显示{scroll+1 if visible else 0}—{min(scroll+capacity,len(visible))}")
        button((15, 594, 160, 633), "打开所选视频")
        button((175, 594, 280, 633), "刷新进度")
        button((295, 594, 450, 633), "导出进度CSV")
        label(465, 598, message[:29], 15, (255, 210, 128))
        return cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)

    def mouse(event, x, y, flags, _):
        nonlocal member, phase, query, scroll, selected, pending
        if event == cv2.EVENT_MOUSEWHEEL:
            delta = (flags >> 16) & 0xffff
            if delta >= 0x8000:
                delta -= 0x10000
            scroll += -3 if delta > 0 else 3
            refresh()
        elif event in (cv2.EVENT_LBUTTONDOWN, cv2.EVENT_LBUTTONDBLCLK):
            if 55 <= y <= 93:
                if 15 <= x <= 262:
                    member = MEMBERS[min(3, (x-15)//64)]
                    scroll, selected = 0, None
                elif 295 <= x <= 535:
                    phase = "initial" if x <= 395 else "review"
                    scroll, selected = 0, None
                elif 565 <= x <= 740:
                    pending = "filter"
                refresh()
            for top, bottom, vid in rows:
                if top <= y < bottom:
                    selected = vid
                    if event == cv2.EVENT_LBUTTONDBLCLK:
                        pending = "open"
            if 594 <= y <= 633:
                if 15 <= x <= 160: pending = "open"
                elif 175 <= x <= 280: refresh()
                elif 295 <= x <= 450: pending = "summary"

    refresh()
    if preview_path is not None:
        write_image(Path(preview_path), draw())
        return
    cv2.namedWindow(title, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(title, mouse)
    started = time.perf_counter()
    try:
        while True:
            cv2.imshow(title, draw())
            key = cv2.waitKeyEx(35)
            if cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                break
            if smoke_test and time.perf_counter() - started >= 1.5:
                print("Task window smoke test passed; no annotation recorded.")
                break
            if key in (27, ord("q"), ord("Q")):
                break
            if key in (ord("1"), ord("2"), ord("3"), ord("4")):
                member, scroll, selected = MEMBERS[key-ord("1")], 0, None
                refresh()
            elif key == 9:
                phase = "review" if phase == "initial" else "initial"
                scroll, selected = 0, None
                refresh()
            elif key in (13, 10):
                pending = "open"
            elif key in (2490368, 2621440, 65362, 65364) and visible:
                at = next((i for i, t in enumerate(visible) if t["video_id"] == selected), 0)
                at = min(max(at + (-1 if key in (2490368, 65362) else 1), 0), len(visible)-1)
                selected = visible[at]["video_id"]
                scroll = min(scroll, at)
                if at >= scroll + capacity: scroll = at - capacity + 1
                refresh()
            action, pending = pending, None
            try:
                if action == "filter":
                    value = ask("视频筛选", "输入视频编号的一部分；留空显示全部：", initial=query)
                    if value is not None:
                        query, scroll, selected = value.strip(), 0, None
                        refresh()
                elif action == "summary":
                    message = "已导出progress.csv：" + str(export_summary(tasks, output_root))
                    print(message, flush=True)
                elif action == "open":
                    task = next((t for t in visible if t["video_id"] == selected), None)
                    if task is None:
                        raise ValueError("请选择视频。")
                    cv2.destroyWindow(title)
                    try:
                        while task is not None:
                            workspace, _ = task_paths(task, member, output_root)
                            if (phase == "initial" and task["video_id"] == "03_007"
                                    and not (workspace / "session.json").exists()
                                    and (PROJECT / "outputs/annotation_pilot/03_007/session.json").exists()):
                                if ask("导入旧试点", "是否复制03_007已有初标为团队工作副本？原文件保留，接管不代表重新标注。", confirm=True):
                                    import_pilot(task, member, output_root)
                            with OutputLock(workspace):
                                print(f"正在核对/准备 {task['video_id']} 缓存，请稍候。", flush=True)
                                session, annotation = prepare_task(task, member, phase, output_root)
                                result = Viewer(session, annotation).run()
                            refresh()
                            if result != "next": break
                            at = next(i for i,t in enumerate(visible) if t["video_id"] == task["video_id"])
                            task = next((t for t in visible[at+1:] if task_status(t,phase,output_root)[0]
                                         not in ("已完成", "待初标")), None)
                            if task: selected = task["video_id"]
                            else: message = "后续没有可开始的未完成任务。"
                    finally:
                        cv2.namedWindow(title, cv2.WINDOW_AUTOSIZE)
                        cv2.setMouseCallback(title, mouse)
                        refresh()
            except (ValueError, OSError, cv2.error) as error:
                message = str(error)
                print("暂停：" + message, flush=True)
                ask("任务暂停", message + "\n点击OK返回任务表，既有标签保留。", confirm=True)
    finally:
        cv2.destroyAllWindows()


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="小组标注任务选择与进度")
    parser.add_argument("--tasks", type=Path, default=DEFAULT_TASKS)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_TEAM)
    parser.add_argument("--generate-tasks", action="store_true")
    parser.add_argument("--summary", action="store_true")
    parser.add_argument("--smoke-test", action="store_true", help="只短暂打开任务窗口，不记录标注")
    parser.add_argument("--preview", type=Path, help="生成任务窗口预览图片，不记录标注")
    args = parser.parse_args()
    if args.generate_tasks:
        tasks = generate_tasks(args.tasks)
        print(f"已生成 {len(tasks)} 段任务：{args.tasks}")
        return
    tasks = load_tasks(args.tasks)
    if args.summary:
        print(export_summary(tasks, args.output_root))
    else:
        launch(tasks, args.output_root, smoke_test=args.smoke_test, preview_path=args.preview)


if __name__ == "__main__":
    main()
