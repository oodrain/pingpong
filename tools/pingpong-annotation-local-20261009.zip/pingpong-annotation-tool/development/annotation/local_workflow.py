"""Portable local projects and standard-package exchange, independent of task assignments."""
from __future__ import annotations

import copy
import hashlib
import re
import shutil
import tempfile
import time
from pathlib import Path

from annotation_core import OutputLock, Session, prepare, write_json
from submission import (digest, export_session, move_folder, read_json, read_records, review_reference,
                        validate_folder, require)

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_WORK = ROOT / 'outputs/local_annotation'
SETTINGS = ROOT / 'outputs/local_annotation_settings.json'
MEMBERS = ('A', 'B', 'C', 'D')
VIDEO_SUFFIXES = {'.mp4', '.avi', '.mov', '.mkv'}


def object_metadata(path):
    data = read_json(Path(path))
    require(isinstance(data, dict) and isinstance(data.get('video_id'), str)
            and re.fullmatch(r'\d{2}_\d{3}', data['video_id']), '对象JSON必须含现有项目编号，如03_007。')
    for name in ('num_frames', 'frame_width', 'frame_height'):
        require(type(data.get(name)) is int and data[name] > 0, f'对象JSON缺少有效的{name}。')
    require(isinstance(data.get('frames'), list)
            and all(isinstance(row, dict) for row in data['frames'])
            and [row.get('frame_id') for row in data['frames']] == list(range(data['num_frames'])),
            '对象JSON必须包含完整的0基连续帧号。')
    return data


def make_entry(annotation, video=None):
    annotation = Path(annotation).resolve()
    data = object_metadata(annotation)
    if video is not None:
        video = Path(video).resolve()
        require(video.is_file(), '所选视频不存在。')
    return {'entry_id': hashlib.sha256(str(annotation).encode('utf-8')).hexdigest()[:20],
            'video_id': data['video_id'], 'annotation': str(annotation),
            'video': str(video) if video else None, 'candidates': [],
            'issue': '' if video else '缺少视频，请手动配对'}


def scan_folder(folder):
    """Never select one candidate when multiple plausible files exist."""
    folder = Path(folder).resolve()
    require(folder.is_dir(), '请选择存在的文件夹。')
    files = sorted(p for p in folder.rglob('*') if p.is_file())
    videos = [p.resolve() for p in files if p.suffix.lower() in VIDEO_SUFFIXES]
    result, errors = [], []
    for path in files:
        if path.suffix.lower() != '.json':
            continue
        try:
            raw = read_json(path)
            if not isinstance(raw, dict) or not {'video_id', 'frames'} <= raw.keys():
                continue  # Skip standard metadata, project settings, sessions and caches.
            data = object_metadata(path)
            entry = make_entry(path)
            scene, clip = data['video_id'].split('_')
            declared = Path(str(data.get('video_path', '')).replace('\\', '/'))
            candidates = {p for p in videos if p.stem == data['video_id']
                          or (p.stem == clip and p.parent.name == scene)}
            for base in (folder, path.parent, *path.parents):
                if base != folder and folder not in base.parents:
                    continue
                proposed = (base / declared).resolve()
                if proposed in videos:
                    candidates.add(proposed)
            if not candidates:
                candidates = {p for p in videos if p.name == declared.name or p.stem == clip}
            entry['candidates'] = sorted(map(str, candidates))
            if len(candidates) == 1:
                entry['video'] = str(next(iter(candidates)))
                entry['issue'] = ''
            elif candidates:
                entry['issue'] = f'有{len(candidates)}个候选视频，请手动配对'
            result.append(entry)
        except (ValueError, OSError, KeyError, TypeError) as error:
            errors.append(f'{path}: {error}')
    return result, errors


def settings():
    return read_json(SETTINGS) if SETTINGS.exists() else {}


def remember(**values):
    state = settings()
    state.update(values)
    write_json(SETTINGS, state)


def range_frames(ranges):
    return [frame for start, end in ranges for frame in range(start, end + 1)]


def bundle(folder):
    folder = Path(folder).resolve()
    meta = validate_folder(folder)
    return meta, {name: read_records(folder / f'{name}.jsonl', name != 'non_table_events')
                  for name in ('events', 'uncertain', 'non_table_events')}


def verify_bundle_inputs(meta, entry):
    data = object_metadata(entry['annotation'])
    require(meta['video_id'] == entry['video_id'] == data['video_id'], '结果编号与对象JSON不同。')
    for path_key, hash_key in (('video', 'video_sha256'), ('annotation', 'annotation_sha256')):
        require(entry.get(path_key) and digest(entry[path_key]) == meta[hash_key], '结果与本地输入哈希不同，停止导入。')
    require((meta['n_frames'], meta['width'], meta['height'])
            == (data['num_frames'], data['frame_width'], data['frame_height']), '结果与JSON帧数/尺寸不同。')


class LocalProject:
    def __init__(self, root=DEFAULT_WORK):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.manifest = self.root / 'local_project.json'
        self.entries = read_json(self.manifest)['items'] if self.manifest.exists() else []

    def save(self):
        with OutputLock(self.root / '_project_lock'):
            write_json(self.manifest, {'schema_version': 1, 'items': self.entries})

    def add(self, entries):
        known = {row['entry_id']: row for row in self.entries}
        for entry in entries:
            # A repeat scan cannot erase an explicitly chosen pairing.
            if entry['entry_id'] not in known:
                self.entries.append(entry)
                known[entry['entry_id']] = entry
        self.save()

    def pairing_issue(self, entry):
        if sum(row['video_id'] == entry['video_id'] for row in self.entries) > 1:
            return '重复视频编号，请移除重复项或另选工作目录'
        if not entry.get('video'):
            return entry.get('issue') or '请手动选择视频'
        if not Path(entry['video']).is_file() or not Path(entry['annotation']).is_file():
            return '输入文件已移动，请重新配对'
        return ''

    def bind(self, entry, video, annotation=None):
        replacement = make_entry(annotation or entry['annotation'], video)
        require(replacement['video_id'] == entry['video_id'], '重新配对必须保留同一视频编号。')
        replacement['entry_id'] = entry['entry_id']
        entry.update(replacement)
        self.save()

    def workspace(self, entry, member, phase):
        require(member in MEMBERS and phase in ('initial', 'review'), '请选择成员与标注阶段。')
        require(re.fullmatch(r'\d{2}_\d{3}', entry['video_id']) is not None, '无效视频编号。')
        return self.root / member / entry['video_id'] / phase

    def _prepare(self, entry, member, phase, output=None):
        require(not self.pairing_issue(entry), self.pairing_issue(entry))
        require(object_metadata(entry['annotation'])['video_id'] == entry['video_id'], 'JSON编号已经改变，停止恢复。')
        workspace = output or self.workspace(entry, member, phase)
        identity = digest(entry['video']) + digest(entry['annotation'])
        frames = self.root / '_frames' / (entry['video_id'] + '-' + hashlib.sha256(identity.encode()).hexdigest()[:20])
        session, annotation = prepare(entry['video'], entry['annotation'], workspace, frames_dir=frames,
                                      completion_policy='manual_attestation')
        prior = session.state['participants'].get(phase)
        require(prior is None or prior == member, '此工作目录属于另一成员，不允许接管。')
        session.state['completion_policy'] = 'manual_attestation'
        session.state['participants'][phase] = member
        (workspace / 'comparison.json').unlink(missing_ok=True)
        return session, annotation

    def open(self, entry, member, phase='initial'):
        output = self.workspace(entry, member, phase)
        require(phase != 'review' or (output / 'session.json').exists(), '请先导入另一成员已完成的标准初标文件包。')
        with OutputLock(output):
            session, annotation = self._prepare(entry, member, phase)
            session.switch_round(phase)
            session.save()
        return session, annotation

    def status(self, entry, member, phase):
        issue = self.pairing_issue(entry)
        if issue:
            return issue
        output = self.workspace(entry, member, phase)
        if not (output / 'session.json').exists():
            return '待导入初标' if phase == 'review' else '未开始'
        state = read_json(output / 'session.json')
        prefix = '已完成' if state['rounds'][phase]['completed_at'] is not None else '进行中'
        if phase == 'review' and self.review_stale(output):
            prefix += ' · 复核过期'
        return prefix

    def review_stale(self, workspace):
        state = read_json(Path(workspace) / 'session.json')
        path = state.get('review_origin')
        if not path or not Path(path).exists():
            return False  # Missing external source is not evidence that its version changed.
        try:
            return review_reference(Path(path)) != state.get('standard_review_reference')
        except (ValueError, OSError, KeyError, TypeError):
            return True

    def import_result(self, entry, member, source, review_source=None):
        """Validate before staging; only a successful full import publishes a new workspace."""
        source = Path(source).resolve()
        meta, records = bundle(source)
        verify_bundle_inputs(meta, entry)
        independent = meta['annotator'] != member
        if independent:
            require(meta['round'] == 'initial' and meta['completed'], '另一成员的结果仅可用已完成初标创建独立复核。')
            phase, initial_source = 'review', source
        else:
            phase = meta['round']
            initial_source = Path(review_source).resolve() if review_source else None
            require(phase != 'review' or initial_source is not None, '恢复复核还需要它所依据的完整初标文件包。')
        initial_meta = initial_records = reference = None
        if initial_source:
            initial_meta, initial_records = bundle(initial_source)
            verify_bundle_inputs(initial_meta, entry)
            reference = review_reference(initial_source)
            require(initial_meta['annotator'] != member, '复核必须来自另一成员的初标。')
            if not independent:
                require(meta['review_of'] == reference, '提供的初标版本不是该复核绑定的来源。')
        output = self.workspace(entry, member, phase)
        output.parent.mkdir(parents=True, exist_ok=True)
        with OutputLock(output.parent / ('.' + phase + '-import-lock')):
            require(not output.exists(), '工作记录已存在；请直接打开恢复，或选择新的工作目录。不会覆盖已有记录。')
            with tempfile.TemporaryDirectory(prefix='import-', dir=output.parent) as temp:
                staged = Path(temp) / phase
                session, annotation = self._prepare(entry, member, phase, staged)
                require(session.meta['fps'] == meta['fps'], '结果与实际解码帧率不同，停止导入。')
                if initial_source:
                    require(session.meta['fps'] == initial_meta['fps'], '初标来源与实际解码帧率不同。')
                    snapshot = staged / '_source' / initial_meta['annotator'] / entry['video_id'] / 'initial'
                    snapshot.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(initial_source, snapshot)
                    require(review_reference(snapshot) == reference, '复制期间来源发生变化，停止导入。')
                    self._load_round(session, initial_meta, initial_records)
                    session.state['standard_review_reference'] = reference
                    session.state['review_origin'] = str(initial_source)
                    # Relative location stays portable when the workspace directory moves.
                    session.state['review_snapshot'] = str(snapshot.relative_to(staged))
                if not independent:
                    self._load_round(session, meta, records)
                    session.state.setdefault('standard_metadata', {})[phase] = copy.deepcopy(meta)
                    session.state.setdefault('standard_records', {})[phase] = copy.deepcopy(records)
                session.state['participants'][phase] = member
                session.switch_round(phase)
                session.save()
                move_folder(staged, output)
        return self.open(entry, member, phase)

    def import_review_batch(self, entries, member, source_root):
        """Import every completed initial bundle under source_root as an independent review."""
        source_root = Path(source_root).resolve()
        require(source_root.is_dir(), '请选择包含初标结果的目录，例如labels\\A或labels。')
        sources, source_errors = {}, []
        for metadata in source_root.rglob('metadata.json'):
            folder = metadata.parent
            if folder.name != 'initial':
                continue
            try:
                meta = validate_folder(folder)
                require(meta['round'] == 'initial' and meta['completed'], '不是已完成初标。')
                require(meta['annotator'] != member, '不能用自己的初标创建独立复核。')
                video_id = meta['video_id']
                if video_id in sources:
                    raise ValueError(f'发现重复初标来源：{sources[video_id]} 和 {folder}')
                sources[video_id] = folder
            except (ValueError, OSError, KeyError, TypeError) as error:
                source_errors.append(f'{folder}: {error}')
        require(sources, '所选目录下没有找到其他成员已完成的initial标准结果。')

        by_id = {entry['video_id']: entry for entry in entries}
        successes, skipped, failures = [], [], list(source_errors)
        for video_id, source in sorted(sources.items()):
            entry = by_id.get(video_id)
            if entry is None:
                failures.append(f'{video_id}: 当前清单缺少同编号视频和对象JSON。')
                continue
            output = self.workspace(entry, member, 'review')
            if (output / 'session.json').exists():
                skipped.append(video_id)
                continue
            try:
                self.import_result(entry, member, source)
                successes.append(video_id)
            except (ValueError, OSError, KeyError, TypeError) as error:
                failures.append(f'{video_id}: {error}')
        return {'successes': successes, 'skipped': skipped, 'failures': failures}

    @staticmethod
    def _load_round(session, meta, records):
        phase = meta['round']
        session.state['participants'][phase] = meta['annotator']
        session.state['events'][phase] = copy.deepcopy(records['events'])
        session.state['uncertain'] += copy.deepcopy(records['uncertain'])
        session.state['non_table'] += copy.deepcopy(records['non_table_events'])
        progress = session.state['rounds'][phase]
        progress.update(completed_at=time.time() if meta['completed'] else None,
                        inspected_all_attested=meta['completed'],
                        completion_basis='manual_attestation' if meta['completed'] else None,
                        no_events_reason=meta['no_events_reason'],
                        reviewed_frames=range_frames(meta['checked_ranges']) if not meta['completed'] else [],
                        seen_frames=range_frames(meta.get('displayed_ranges') or []),
                        displayed_unavailable=meta.get('displayed_ranges') is None)

    def export(self, entry, member, phase, output_root):
        output_root = Path(output_root).resolve()
        require(output_root != self.root, '导出目录不能与工作目录相同，请选择独立的labels目录。')
        workspace = self.workspace(entry, member, phase)
        require((workspace / 'session.json').is_file(), '本成员还没有该阶段的工作记录。')
        with OutputLock(workspace):
            state = read_json(workspace / 'session.json')
            require(state['participants'].get(phase) == member, '结果身份与当前成员不同。')
            # Check current bytes, not just paths or the metadata saved previously.
            verify_bundle_inputs({**state['video'], **state['inputs']}, entry)
            review_source = workspace / state['review_snapshot'] if phase == 'review' else None
            # A review-only batch is still a self-contained exchange tree.
            if review_source:
                initial_meta = validate_folder(review_source)
                initial_target = output_root / initial_meta['annotator'] / entry['video_id'] / 'initial'
                if not initial_target.exists():
                    initial_target.parent.mkdir(parents=True, exist_ok=True)
                    temp = Path(tempfile.mkdtemp(prefix='source-', dir=initial_target.parent))
                    try:
                        shutil.copytree(review_source, temp / 'initial')
                        move_folder(temp / 'initial', initial_target)
                    finally:
                        shutil.rmtree(temp)
            target = export_session(workspace, output_root, phase, review_source=review_source,
                                    schema_version=2, backup_root=self.root / '_export_backups')
            meta, records = bundle(target)
            state.setdefault('standard_metadata', {})[phase] = meta
            state.setdefault('standard_records', {})[phase] = records
            write_json(workspace / 'session.json', state)
            return target

    def export_batch(self, entries, member, phase, output_root):
        successes, failures = [], []
        for entry in entries:
            try:
                successes.append(str(self.export(entry, member, phase, output_root)))
            except (ValueError, OSError, KeyError, TypeError) as error:
                failures.append(f"{entry['video_id']}: {error}")
        return {'successes': successes, 'failures': failures}
