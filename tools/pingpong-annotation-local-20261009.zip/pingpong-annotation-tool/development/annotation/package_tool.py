"""Build the distributable Windows tool from an explicit list; never include user data."""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
CODE = ROOT / 'development/annotation'


def build(output):
    output = Path(output)
    files = {f'development/annotation/{path.name}': path for path in CODE.iterdir()
             if path.is_file() and (path.suffix in {'.py', '.ps1', '.cmd', '.txt'} or path.name in {'README.md', 'tasks.json'})}
    # The root README is the end-user guide shipped with the standalone tool.
    # Keep a single source of truth instead of referring to a removed file.
    files['README.md'] = ROOT / 'README.md'
    for relative in ('安装标注环境.cmd', '启动标注.cmd', 'labels/README.md',
                     'docs/guides/标注工具_组员上手说明.md', 'docs/guides/标注文件与GitHub提交标准.md'):
        files[relative] = ROOT / relative
    output.parent.mkdir(parents=True, exist_ok=True)
    records = []
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            archive.writestr('pingpong-annotation-tool/' + name, data)
            records.append({'path': name, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    manifest = output.with_suffix('.manifest.json')
    manifest.write_text(json.dumps({'format': 'local-annotation-v2', 'files': records,
                        'zip_sha256': hashlib.sha256(output.read_bytes()).hexdigest()},
                        ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return output, manifest


def main():
    date = datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'outputs/distribution' / f'pingpong-annotation-local-{date}.zip')
    args = parser.parse_args()
    output, manifest = build(args.output)
    print(output)
    print(manifest)


if __name__ == '__main__':
    main()
