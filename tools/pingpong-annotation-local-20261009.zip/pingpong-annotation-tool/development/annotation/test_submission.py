"""Meaningful interchange and provenance checks; no real label files are changed."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from submission import export_session, read_json, read_records, review_reference, validate_data, validate_tree, validate_folder


class SubmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.meta = {
            'schema_version': 1, 'video_id': '03_007', 'annotator': 'A', 'round': 'initial',
            'width': 640, 'height': 360, 'n_frames': 5, 'fps': 25.0,
            'video_sha256': 'a' * 64, 'annotation_sha256': 'b' * 64,
            'completed': True, 'checked_ranges': [[0, 4]], 'no_events_reason': '',
            'label_version': 1, 'updated_at': '2026-10-07T12:00:00+08:00',
            'tool': 'test', 'source_type': 'manual', 'review_of': None,
        }
        self.events = [{'event_id': 'event-2', 'video_id': '03_007', 'frame_id': 2, 'x': 100.0, 'y': 90,
                        'event_type': 'table_bounce', 'review_state': 'provisional', 'round': 'initial', 'annotator': 'A'}]

    def tearDown(self):
        self.temp.cleanup()

    def folder(self, meta=None, events=None):
        meta = meta or self.meta
        path = self.root / 'labels' / meta['annotator'] / meta['video_id'] / meta['round']
        path.mkdir(parents=True, exist_ok=True)
        (path / 'metadata.json').write_text(json.dumps(meta), encoding='utf-8')
        (path / 'events.jsonl').write_text(''.join(json.dumps(e) + '\n' for e in (self.events if events is None else events)), encoding='utf-8')
        (path / 'uncertain.jsonl').write_text('', encoding='utf-8')
        return path

    def session(self, review=False):
        state = {
            'video': {k: self.meta[k] for k in ('video_id', 'width', 'height', 'n_frames', 'fps')},
            'inputs': {k: self.meta[k] for k in ('video_sha256', 'annotation_sha256')},
            'participants': {'initial': 'A', 'review': 'B'},
            'rounds': {phase: {'completed_at': 1, 'inspected_all_attested': True,
                              'reviewed_frames': [], 'seen_frames': list(range(5)), 'no_events_reason': ''}
                       for phase in ('initial', 'review')},
            'events': {'initial': copy.deepcopy(self.events), 'review': copy.deepcopy(self.events) if review else []},
            'uncertain': [], 'non_table': [],
        }
        workspace = self.root / ('review-workspace' if review else 'workspace')
        workspace.mkdir(exist_ok=True)
        (workspace / 'session.json').write_text(json.dumps(state), encoding='utf-8')
        return workspace, state

    def test_valid_and_partial_are_distinct(self):
        validate_data(self.meta, self.events, [], [])
        partial = dict(self.meta, completed=False, checked_ranges=[])
        validate_data(partial, self.events, [], [])
        with self.assertRaises(ValueError):
            validate_data(dict(partial, completed=True), self.events, [], [])

    def test_empty_complete_requires_explanation(self):
        with self.assertRaises(ValueError):
            validate_data(self.meta, [], [], [])
        validate_data(dict(self.meta, no_events_reason='No confirmable bounce after full inspection'), [], [], [])

    def test_reject_false_numeric_values_and_out_of_bounds(self):
        for key, value in (('frame_id', True), ('frame_id', 5), ('x', True), ('x', float('nan')), ('x', 640), ('y', -1)):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_data(self.meta, [dict(self.events[0], **{key: value})], [], [])

    def test_duplicate_event_not_silently_counted_twice(self):
        for extra in (self.events[0], dict(self.events[0], event_id='another-id')):
            with self.assertRaises(ValueError):
                validate_data(self.meta, self.events + [extra], [], [])

    def test_uncertain_interval_does_not_allow_fake_coordinates(self):
        row = {'event_id': 'uncertain-1', 'video_id': '03_007', 'annotator': 'A', 'round': 'initial',
               'frame_start': 1, 'frame_end': 3, 'reason': 'occluded', 'review_state': 'uncertain'}
        validate_data(self.meta, self.events, [row], [])
        with self.assertRaises(ValueError):
            validate_data(self.meta, self.events, [dict(row, x=0)], [])

    def test_reject_duplicate_json_keys_and_nonstandard_numbers(self):
        path = self.root / 'bad.json'
        for text in ('{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}'):
            path.write_text(text, encoding='utf-8')
            with self.assertRaises(ValueError):
                read_json(path)

    def test_do_not_upload_video_or_session_with_submission(self):
        folder = self.folder()
        (folder / 'session.json').write_text('{}', encoding='utf-8')
        with self.assertRaises(ValueError):
            validate_folder(folder)

    def test_task_assignment_checked(self):
        self.folder()
        path = self.root / 'tasks.json'
        path.write_text(json.dumps({'tasks': [{'video_id': '03_007', 'annotator': 'C', 'reviewer': 'D'}]}), encoding='utf-8')
        with self.assertRaises(ValueError):
            validate_tree(self.root / 'labels', path)

    def test_actual_input_hash_mismatch_rejected(self):
        self.folder()
        (self.root / 'video.mp4').write_bytes(b'synthetic')
        (self.root / 'object.json').write_bytes(b'{}')
        path = self.root / 'tasks.json'
        path.write_text(json.dumps({'tasks': [{'video_id': '03_007', 'annotator': 'A', 'reviewer': 'B', 'video': 'video.mp4', 'annotation': 'object.json'}]}), encoding='utf-8')
        with self.assertRaises(ValueError):
            validate_tree(self.root / 'labels', path, self.root)

    def test_export_preserves_source_and_does_not_accept_playback_as_complete(self):
        workspace, state = self.session()
        state['imported_from'] = {'note': 'old pilot'}
        state['rounds']['initial']['inspected_all_attested'] = False
        (workspace / 'session.json').write_text(json.dumps(state), encoding='utf-8')
        original = (workspace / 'session.json').read_bytes()
        target = export_session(workspace, self.root / 'labels', 'initial', 1)
        meta = validate_folder(target)
        self.assertFalse(meta['completed'])
        self.assertEqual(meta['source_type'], 'imported')
        self.assertEqual((workspace / 'session.json').read_bytes(), original)
        with self.assertRaises(ValueError):
            export_session(workspace, self.root / 'labels', 'initial', 1)

    def test_independent_review_bound_to_source_and_staleness_detected(self):
        workspace, _ = self.session()
        source = export_session(workspace, self.root / 'labels', 'initial', 1)
        reviewer, _ = self.session(review=True)
        target = export_session(reviewer, self.root / 'labels', 'review', 1, source)
        self.assertEqual(validate_folder(target)['annotator'], 'B')
        self.assertEqual(validate_tree(self.root / 'labels')['warnings'], [])
        original = read_json(source / 'metadata.json')
        original['label_version'] = 2
        (source / 'metadata.json').write_text(json.dumps(original), encoding='utf-8')
        self.assertEqual(len(validate_tree(self.root / 'labels')['warnings']), 1)

    def test_export_cannot_bind_review_to_different_initial_snapshot(self):
        source = self.folder(events=[dict(self.events[0], x=150)])
        reviewer, _ = self.session(review=True)
        with self.assertRaises(ValueError):
            export_session(reviewer, self.root / 'labels', 'review', 1, source)

    def test_version_update_keeps_previous_submission_backup(self):
        workspace, state = self.session()
        target = export_session(workspace, self.root / 'labels', 'initial', 1)
        original = (target / 'events.jsonl').read_bytes()
        state['events']['initial'][0]['x'] = 120
        (workspace / 'session.json').write_text(json.dumps(state), encoding='utf-8')
        with patch('submission.ROOT', self.root):
            export_session(workspace, self.root / 'labels', 'initial', 2)
        self.assertEqual(validate_folder(target)['label_version'], 2)
        snapshots = list((self.root / 'outputs/submission_backups').rglob('events.jsonl'))
        self.assertEqual(len(snapshots), 1)
        self.assertEqual(snapshots[0].read_bytes(), original)

    def test_windows_line_endings_do_not_make_reviews_stale(self):
        source = self.folder()
        reference = review_reference(source)
        for name in ('metadata.json', 'events.jsonl', 'uncertain.jsonl'):
            path = source / name
            path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n').replace(b'\n', b'\r\n'))
        self.assertEqual(reference, review_reference(source))


if __name__ == '__main__':
    unittest.main()
