"""Check the Windows annotation environment without touching data or labels."""
import importlib.metadata
import re
import struct
import sys
from pathlib import Path


def main():
    if sys.version_info[:2] != (3, 12) or struct.calcsize("P") != 8:
        raise ValueError("Please use 64-bit Python 3.12 for this annotation environment.")
    requirements = Path(__file__).with_name("requirements-lock.txt")
    for line in requirements.read_text(encoding="utf-8-sig").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        package, expected = line.strip().split("==")
        actual = importlib.metadata.version(package)
        if actual != expected:
            raise ValueError(f"{package}: expected {expected}, found {actual}; run the installer.")
    import cv2
    import numpy
    from PIL import Image
    if re.search(r"GUI:\s+NONE", cv2.getBuildInformation()):
        raise ValueError("OpenCV has no GUI support. Do not install opencv-python-headless here.")
    print(f"READY: Python {sys.version.split()[0]}, OpenCV {cv2.__version__}, NumPy {numpy.__version__}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, ImportError, importlib.metadata.PackageNotFoundError) as error:
        print(f"Environment not ready: {error}", file=sys.stderr)
        sys.exit(1)
