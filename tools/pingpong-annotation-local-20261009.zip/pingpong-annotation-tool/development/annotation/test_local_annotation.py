"""Local import/export integration tests with real, tiny videos and disposable workspaces."""
import copy
import json
import shutil
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import cv2
import numpy as np

from annotation_core import Session, write_json
from annotate import Viewer
from local_workflow import LocalProject, make_entry, scan_folder
from local_annotation import LocalWindow
from submission import (export_session, read_json, read_records, review_reference,
                        validate_data, validate_folder, validate_tree)


class LocalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.data = self.root / '收到的数据'
        self.data.mkdir()
        self.video = self.data / '03_007.mp4'
        writer = cv2.VideoWriter(str(self.video), cv2.VideoWriter_fourcc(*'mp4v'), 25, (64, 32))
        self.assertTrue(writer.isOpened())
        for i in range(6):
            writer.write(np.full((32, 64, 3), i * 25, dtype=np.uint8))
        writer.release()
        self.annotation = self.data / '对象.json'
        write_json(self.annotation, {'video_id': '03_007', 'video_path': 'old/03/007.mp4',
                   'num_frames': 6, 'frame_width': 64, 'frame_height': 32,
                   'frames': [{'frame_id': i, 'annotations': []} for i in range(6)]})
        self.entry = make_entry(self.annotation, self.video)
        self.project = LocalProject(self.root / 'work')
        self.project.add([self.entry])
        self.labels = self.root / 'labels'

    def initial(self, complete=True, rich=False):
        session, annotation = self.project.open(self.entry, 'A')
        session.put_event(2, 15.5, 20)
        if rich:
            session.put_non_table(3, 'net_contact', reason='visible net contact')
            session.put_uncertain(0, 1, 'occluded')
        if complete:
            session.complete(inspected_all=True)
        session.save()
        return session, annotation

    def source(self, complete=True, rich=False):
        self.initial(complete, rich)
        return self.project.export(self.entry, 'A', 'initial', self.labels)

    def new_project(self, name):
        project = LocalProject(self.root / name)
        project.add([copy.deepcopy(self.entry)])
        return project

    def test_scan_auto_missing_ambiguous_and_ignores_standard_files(self):
        entries, errors = scan_folder(self.data)
        self.assertEqual(errors, [])
        self.assertEqual(entries[0]['video'], str(self.video.resolve()))
        self.video.rename(self.data / 'unrelated.mp4')
        entries, _ = scan_folder(self.data)
        self.assertIsNone(entries[0]['video'])
        for sub in ('one', 'two'):
            folder = self.data / sub
            folder.mkdir()
            shutil.copyfile(self.data / 'unrelated.mp4', folder / '03_007.mp4')
        write_json(self.data / 'metadata.json', {'video_id': '03_007', 'schema_version': 2})
        entries, errors = scan_folder(self.data)
        self.assertEqual(len(entries), 1)
        self.assertEqual(len(entries[0]['candidates']), 2)
        self.assertIsNone(entries[0]['video'])

    def test_scan_scene_paths_and_moved_official_video_path(self):
        folder = self.data / 'rallies/A/03'
        folder.mkdir(parents=True)
        video = folder / '007.mp4'
        self.video.rename(video)
        entries, _ = scan_folder(self.data)
        self.assertEqual(entries[0]['video'], str(video.resolve()))

    def test_repeated_scan_preserves_manual_pairing(self):
        unpaired = make_entry(self.annotation)
        self.project.add([unpaired])
        self.assertEqual(self.project.entries[0]['video'], str(self.video.resolve()))
        self.assertEqual(len(self.project.entries), 1)

    def test_duplicate_ids_block_until_duplicate_removed(self):
        duplicate = self.data / 'duplicate.json'
        shutil.copyfile(self.annotation, duplicate)
        self.project.add([make_entry(duplicate, self.video)])
        with self.assertRaisesRegex(ValueError, '重复'):
            self.project.open(self.entry, 'A')
        self.assertFalse((self.project.workspace(self.entry, 'A', 'initial') / 'session.json').exists())

    def test_manual_completion_without_coverage_and_real_displayed_ranges(self):
        session, annotation = self.initial()
        self.assertEqual(session.progress['seen_frames'], [])
        target = self.project.export(self.entry, 'A', 'initial', self.labels)
        meta = validate_folder(target)
        self.assertTrue(meta['completed'])
        self.assertEqual(meta['checked_ranges'], [[0, 5]])
        self.assertEqual(meta['displayed_ranges'], [])
        self.assertEqual(meta['completion_basis'], 'manual_attestation')
        self.assertEqual(meta['schema_version'], 2)
        viewer = Viewer(session, annotation)
        with patch.object(viewer, 'confirm', return_value=True):
            viewer.handle_key(ord('c'))
        self.assertIsNotNone(session.progress['completed_at'])

    def test_viewer_can_complete_at_first_frame_and_drafts_still_block(self):
        session, annotation = self.project.open(self.entry, 'A')
        session.put_event(2, 20, 20)
        viewer = Viewer(session, annotation)
        viewer.pending = (10, 10)
        with patch.object(viewer, 'confirm', return_value=True):
            viewer.handle_key(ord('c'))
            self.assertIsNone(session.progress['completed_at'])
            viewer.handle_key(ord('k'))
            viewer.handle_key(ord('c'))
        self.assertIsNotNone(session.progress['completed_at'])
        self.assertEqual(session.progress['seen_frames'], [])

    def test_empty_completion_reason_freeze_and_reopen_history(self):
        session, _ = self.project.open(self.entry, 'A')
        with self.assertRaises(ValueError):
            session.complete(inspected_all=True)
        session.complete('only occlusion', inspected_all=True)
        with self.assertRaises(ValueError):
            session.put_event(1, 10, 10)
        session.reopen('correct after discussion')
        session.put_event(1, 10, 10)
        session.save()
        self.assertIsNone(session.progress['completed_at'])
        self.assertEqual(len(list((session.output / 'history').glob('*.json'))), 1)

    def test_restore_moved_inputs_and_reject_changed_hash_without_overwrite(self):
        session, _ = self.initial(False)
        relocated = self.root / '新目录'
        relocated.mkdir()
        video, annotation = relocated / 'video.mp4', relocated / 'object.json'
        shutil.copyfile(self.video, video)
        shutil.copyfile(self.annotation, annotation)
        self.project.bind(self.entry, video, annotation)
        restored, _ = self.project.open(self.entry, 'A')
        self.assertEqual(restored.events, session.events)
        prior = (restored.output / 'session.json').read_bytes()
        video.write_bytes(b'wrong input')
        with self.assertRaises(ValueError):
            self.project.open(self.entry, 'A')
        self.assertEqual((restored.output / 'session.json').read_bytes(), prior)

    def test_import_export_roundtrip_no_rewrite_then_version_and_backup(self):
        source = self.source(rich=True)
        original = {p.name: p.read_bytes() for p in source.iterdir()}
        project = self.new_project('second-machine')
        session, _ = project.import_result(self.entry, 'A', source)
        target = project.export(self.entry, 'A', 'initial', self.root / 'returned')
        self.assertEqual({p.name: p.read_bytes() for p in target.iterdir()}, original)
        project.export(self.entry, 'A', 'initial', self.root / 'returned')
        self.assertEqual(validate_folder(target)['label_version'], 1)
        self.assertFalse((project.root / '_export_backups').exists())
        session.reopen('adjust position')
        session.put_event(2, 17, 20)
        session.complete(inspected_all=True)
        session.save()
        project.export(self.entry, 'A', 'initial', self.root / 'returned')
        self.assertEqual(validate_folder(target)['label_version'], 2)
        self.assertEqual(len(list((project.root / '_export_backups').rglob('metadata.json'))), 1)
        self.assertEqual({p.name: p.read_bytes() for p in source.iterdir()}, original)

    def test_same_member_v1_import_keeps_unknown_display_history_and_drafts(self):
        session, _ = self.initial(False, True)
        target = export_session(session.output, self.labels, 'initial', 1)
        project = self.new_project('legacy-machine')
        restored, _ = project.import_result(self.entry, 'A', target)
        self.assertEqual(restored.events, session.events)
        exported = project.export(self.entry, 'A', 'initial', self.root / 'v2labels')
        meta = validate_folder(exported)
        self.assertIsNone(meta['displayed_ranges'])
        self.assertFalse(meta['completed'])

    def test_result_import_never_overwrites_existing_session(self):
        source = self.source()
        prior = (self.project.workspace(self.entry, 'A', 'initial') / 'session.json').read_bytes()
        with self.assertRaisesRegex(ValueError, '不会覆盖'):
            self.project.import_result(self.entry, 'A', source)
        self.assertEqual((self.project.workspace(self.entry, 'A', 'initial') / 'session.json').read_bytes(), prior)

    def test_hash_mismatch_and_decode_mismatch_do_not_publish_import(self):
        source = self.source()
        project = self.new_project('bad-import')
        path = source / 'metadata.json'
        meta = read_json(path)
        meta['video_sha256'] = '0' * 64
        write_json(path, meta)
        with self.assertRaises(ValueError):
            project.import_result(self.entry, 'A', source)
        self.assertFalse(project.workspace(self.entry, 'A', 'initial').exists())
        meta['video_sha256'] = read_json(self.project.workspace(self.entry, 'A', 'initial') / 'session.json')['inputs']['video_sha256']
        meta['fps'] = 24
        write_json(path, meta)
        with self.assertRaises(ValueError):
            project.import_result(self.entry, 'A', source)
        self.assertFalse(project.workspace(self.entry, 'A', 'initial').exists())

    def test_independent_review_hidden_until_completion_and_export_self_contained(self):
        source = self.source(rich=True)
        before = {p.name: p.read_bytes() for p in source.iterdir()}
        project = self.new_project('review-machine')
        session, annotation = project.import_result(self.entry, 'B', source)
        viewer = Viewer(session, annotation)
        self.assertEqual(session.round, 'review')
        self.assertEqual(viewer.visible_records(), [])
        viewer.handle_key(ord('h'))
        self.assertFalse(viewer.show_reference)
        viewer.handle_key(ord('r'))
        self.assertEqual(session.round, 'review')
        self.assertFalse((session.output / 'comparison.json').exists())
        self.assertFalse((session.output / 'review_comparison.json').exists())
        session.put_event(2, 15, 20)
        session.complete(inspected_all=True)
        session.save()
        viewer.handle_key(ord('h'))
        self.assertTrue(viewer.show_reference)
        target = project.export(self.entry, 'B', 'review', self.root / 'review-labels')
        self.assertEqual(validate_folder(target)['review_of'], review_reference(source))
        self.assertEqual(validate_tree(self.root / 'review-labels')['warnings'], [])
        self.assertEqual({p.name: p.read_bytes() for p in source.iterdir()}, before)

    def test_other_member_cannot_import_draft_or_review_as_initial(self):
        source = self.source(False)
        project = self.new_project('review-machine')
        with self.assertRaises(ValueError):
            project.import_result(self.entry, 'B', source)
        self.assertFalse(project.workspace(self.entry, 'B', 'review').exists())

    def test_review_stale_after_initial_changes_snapshot_stays_bound(self):
        source = self.source()
        project = self.new_project('review-machine')
        session, _ = project.import_result(self.entry, 'B', source)
        self.assertFalse(project.review_stale(session.output))
        meta = read_json(source / 'metadata.json')
        meta['label_version'] += 1
        write_json(source / 'metadata.json', meta)
        self.assertTrue(project.review_stale(session.output))
        snapshot = session.output / session.state['review_snapshot']
        self.assertEqual(validate_folder(snapshot)['label_version'], 1)

    def test_resume_own_review_requires_exact_source_version(self):
        source = self.source()
        reviewer = self.new_project('review-machine')
        session, _ = reviewer.import_result(self.entry, 'B', source)
        session.put_event(2, 16, 20)
        session.complete(inspected_all=True)
        session.save()
        review = reviewer.export(self.entry, 'B', 'review', self.labels)
        project = self.new_project('third-machine')
        with self.assertRaises(ValueError):
            project.import_result(self.entry, 'B', review)
        restored, _ = project.import_result(self.entry, 'B', review, source)
        self.assertEqual(restored.events, session.events)
        self.assertEqual(restored.state['standard_review_reference'], review_reference(source))

    def test_auto_version_unchanged_export_does_not_rewrite_any_file(self):
        source = self.source()
        before = {p.name: (p.read_bytes(), p.stat().st_mtime_ns) for p in source.iterdir()}
        self.project.export(self.entry, 'A', 'initial', self.labels)
        self.assertEqual(before, {p.name: (p.read_bytes(), p.stat().st_mtime_ns) for p in source.iterdir()})

    def test_export_failure_rolls_back_entire_previous_folder(self):
        source = self.source()
        before = {p.name: p.read_bytes() for p in source.iterdir()}
        session, _ = self.project.open(self.entry, 'A')
        session.reopen('change')
        session.put_event(2, 17, 20)
        session.complete(inspected_all=True)
        session.save()
        rename = Path.rename
        def fail_staged(path, target):
            if path.name.startswith('submission-') and not path.name.endswith('-previous'):
                raise OSError('simulated final publish failure')
            return rename(path, target)
        with patch('submission.Path.rename', new=fail_staged), self.assertRaises(OSError):
            self.project.export(self.entry, 'A', 'initial', self.labels)
        self.assertEqual(before, {p.name: p.read_bytes() for p in source.iterdir()})
        self.assertEqual(validate_folder(source)['label_version'], 1)

    def test_batch_exports_successes_despite_failed_member_entry(self):
        self.initial()
        missing = dict(self.entry, video_id='03_008', entry_id='missing')
        report = self.project.export_batch([missing, self.entry], 'A', 'initial', self.labels)
        self.assertEqual(len(report['successes']), 1)
        self.assertEqual(len(report['failures']), 1)
        self.assertTrue((self.labels / 'A/03_007/initial/events.jsonl').exists())

    def test_v2_rejects_false_coverage_and_invalid_completion_basis(self):
        source = self.source()
        meta = validate_folder(source)
        events = read_records(source / 'events.jsonl')
        for key, value in (('completion_basis', None), ('displayed_ranges', [[0, 6]]),
                           ('displayed_ranges', [[True, 2]]), ('displayed_ranges', [[0, 1], [2, 3]])):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_data(dict(meta, **{key: value}), events, [], [])

    def test_imported_custom_record_ids_survive_updates(self):
        source = self.source(rich=True)
        for name in ('events', 'uncertain', 'non_table_events'):
            path = source / f'{name}.jsonl'
            rows = read_records(path)
            rows[0]['event_id'] = name + '-custom'
            path.write_text(''.join(json.dumps(row) + '\n' for row in rows), encoding='utf-8')
        project = self.new_project('custom-ids')
        session, _ = project.import_result(self.entry, 'A', source)
        session.reopen('update imported records')
        session.put_event(2, 16, 20)
        session.put_uncertain(0, 1, 'clarified occlusion')
        session.put_non_table(3, 'net_contact', reason='clarified net')
        self.assertEqual(session.events[0]['event_id'], 'events-custom')
        self.assertEqual(session.state['uncertain'][0]['event_id'], 'uncertain-custom')
        self.assertEqual(len(session.state['uncertain']), 1)
        self.assertEqual(session.state['non_table'][0]['event_id'], 'non_table_events-custom')

    def test_label_version_is_preserved_across_export_destinations(self):
        source = self.source()
        session, _ = self.project.open(self.entry, 'A')
        session.reopen('adjust')
        session.put_event(2, 18, 20)
        session.complete(inspected_all=True)
        session.save()
        self.project.export(self.entry, 'A', 'initial', self.labels)
        self.assertEqual(validate_folder(source)['label_version'], 2)
        other = self.project.export(self.entry, 'A', 'initial', self.root / 'other-labels')
        self.assertEqual(validate_folder(other)['label_version'], 2)
        self.assertEqual((other / 'metadata.json').read_bytes(), (source / 'metadata.json').read_bytes())

    def wait_ui(self, window):
        deadline = time.monotonic() + 10
        while window.busy and time.monotonic() < deadline:
            window.poll()
            time.sleep(0.01)
        self.assertFalse(window.busy, 'background action did not finish')

    def test_ui_single_import_buttons_and_mouse_selection(self):
        project = LocalProject(self.root / 'ui-work')
        window = LocalWindow(project, persist=False)
        with patch('local_annotation.pick_file', side_effect=[str(self.video), str(self.annotation)]):
            window.action('pair')
        self.assertEqual(project.entries[0]['video_id'], '03_007')
        window.draw()
        window.action('clear')
        window.mouse(cv2.EVENT_LBUTTONDOWN, 30, 280, 0, None)
        self.assertEqual(window.current()['video_id'], '03_007')
        window.mouse(cv2.EVENT_LBUTTONDOWN, 110, 100, 0, None)
        self.assertEqual(window.pending, 'member:B')
        window.action(window.pending)
        self.assertEqual(window.member, 'B')

    def test_ui_folder_scan_and_batch_export_complete_path(self):
        window = LocalWindow(self.new_project('ui-work'), persist=False)
        with patch('local_annotation.pick_folder', return_value=str(self.data)):
            window.action('scan')
            self.wait_ui(window)
        entry = window.project.entries[0]
        session, _ = window.project.open(entry, 'A')
        session.put_event(2, 15, 20)
        session.complete(inspected_all=True)
        session.save()
        with patch('local_annotation.pick_folder', return_value=str(self.labels)), patch('local_annotation.ask') as report:
            window.action('batch')
            self.wait_ui(window)
            self.assertIn('成功', report.call_args.args[1])
        self.assertEqual(validate_tree(self.labels)['completed'], 1)

    def test_ui_result_import_selects_independent_review(self):
        source = self.source()
        window = LocalWindow(self.new_project('ui-review'), persist=False)
        window.member = 'B'
        window.selected = self.entry['entry_id']
        window.selection = {window.selected}
        with patch('local_annotation.pick_folder', return_value=str(source)):
            window.action('import')
            self.wait_ui(window)
        self.assertEqual(window.phase, 'review')
        self.assertEqual(window.states[self.entry['entry_id']], '进行中')

    def test_batch_review_import_matches_sources_and_skips_existing(self):
        self.source()
        project = self.new_project('batch-review')
        report = project.import_review_batch(project.entries, 'B', self.labels / 'A')
        self.assertEqual(report, {'successes': ['03_007'], 'skipped': [], 'failures': []})
        self.assertTrue((project.workspace(self.entry, 'B', 'review') / 'session.json').exists())
        report = project.import_review_batch(project.entries, 'B', self.labels)
        self.assertEqual(report, {'successes': [], 'skipped': ['03_007'], 'failures': []})

    def test_ui_batch_review_import_selects_review_phase(self):
        self.source()
        window = LocalWindow(self.new_project('ui-batch-review'), persist=False)
        window.member = 'B'
        with patch('local_annotation.pick_folder', return_value=str(self.labels / 'A')), \
                patch('local_annotation.ask') as report:
            window.action('import_reviews')
            self.wait_ui(window)
        self.assertEqual(window.phase, 'review')
        self.assertEqual(window.states[self.entry['entry_id']], '进行中')
        self.assertIn('成功：03_007', report.call_args.args[1])


if __name__ == '__main__':
    unittest.main()
