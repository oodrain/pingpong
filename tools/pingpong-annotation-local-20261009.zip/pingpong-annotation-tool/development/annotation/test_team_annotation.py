"""Team workflow regression tests. All generated labels live in temporary folders."""
import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import cv2
import numpy as np

from annotation_core import Session, prepare, read_json, write_json
from annotate import Viewer
from team_annotation import (generate_tasks, load_tasks, prepare_task, task_paths,
                             task_status, export_summary, snapshot_hash, initial_snapshot)


class Capture:
    def __init__(self, count=3):
        self.index, self.count = 0, count
    def isOpened(self): return True
    def getBackendName(self): return "test"
    def get(self, prop): return 25 if prop == cv2.CAP_PROP_FPS else self.count
    def read(self):
        self.index += 1
        return (True, np.full((16, 32, 3), self.index, np.uint8)) if self.index <= self.count else (False, None)
    def release(self): pass


class TeamTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.video, self.annotation = self.root / "video.mp4", self.root / "annotation.json"
        self.video.write_bytes(b"video-content")
        write_json(self.annotation, {"video_id": "clip", "num_frames": 3,
                   "frame_width": 32, "frame_height": 16,
                   "frames": [{"frame_id": i} for i in range(3)]})
        self.task = {"video_id": "clip", "video": "video.mp4", "annotation": "annotation.json",
                     "n_frames_declared": 3, "annotator": "A", "reviewer": "B"}
        self.team = self.root / "team"

    def prepared(self, output=None, **kwargs):
        with patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()):
            return prepare(self.video, self.annotation, output or self.root / "work", **kwargs)[0]

    def finish(self, session):
        for i in range(3):
            session.set_frame(i)
            session.mark_seen()
        session.complete(inspected_all=True)
        session.save()

    def test_no_v_completion_requires_coverage_and_explicit_attestation(self):
        session = self.prepared()
        session.put_event(1, 10, 8)
        with self.assertRaises(ValueError):
            session.complete(inspected_all=True)
        for i in range(3):
            session.set_frame(i)
            session.mark_seen()
        with self.assertRaises(ValueError):
            session.complete()
        session.complete(inspected_all=True)
        self.assertEqual(session.progress["reviewed_frames"], [])
        session.switch_round("selfcheck")  # Immediate; no mandatory personal second pass.
        self.assertEqual(session.events, [])

    def test_cross_review_is_independent_and_preserves_source(self):
        with patch("team_annotation.PROJECT", self.root), patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()):
            initial, annotation = prepare_task(self.task, "A", "initial", self.team)
            initial.put_event(1, 10, 8)
            self.finish(initial)
            source_path = initial.output / "session.json"
            before = source_path.read_bytes()
            review, annotation = prepare_task(self.task, "B", "review", self.team)
            viewer = Viewer(review, annotation)
            self.assertEqual(viewer.visible_records(), [])
            self.assertFalse(viewer.show_reference)
            viewer.handle_key(ord("h"))
            self.assertFalse(viewer.show_reference)
            self.assertFalse((review.output / "review_comparison.json").exists())
            review.put_event(1, 11, 8)
            self.finish(review)
            self.assertEqual(len(read_json(review.output / "review_comparison.json")["matches"]), 1)
            self.assertEqual(source_path.read_bytes(), before)
            viewer.handle_key(ord("h"))
            self.assertTrue(viewer.show_reference)
            self.assertEqual(task_status(self.task, "review", self.team)[0], "已完成")
            self.assertIn("clip", export_summary([self.task], self.team).read_text("utf-8-sig"))

    def test_reviewer_identity_and_incomplete_source_are_rejected(self):
        with patch("team_annotation.PROJECT", self.root), patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()):
            initial, _ = prepare_task(self.task, "A", "initial", self.team)
            with self.assertRaises(ValueError): prepare_task(self.task, "A", "review", self.team)
            with self.assertRaises(ValueError): prepare_task(self.task, "B", "review", self.team)
            initial.state["participants"]["review"] = "A"
            initial.put_event(1, 10, 8)
            self.finish(initial)
            with self.assertRaises(ValueError): initial.switch_round("review")

    def test_changed_initial_invalidates_review_but_browsing_does_not(self):
        with patch("team_annotation.PROJECT", self.root), patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()):
            initial, _ = prepare_task(self.task, "A", "initial", self.team)
            initial.put_event(1, 10, 8)
            self.finish(initial)
            prepare_task(self.task, "B", "review", self.team)
            initial.set_frame(0)
            initial.save()
            prepare_task(self.task, "B", "review", self.team)
            initial.reopen("修正球心")
            initial.put_event(1, 20, 8)
            self.finish(initial)
            with self.assertRaises(ValueError): prepare_task(self.task, "B", "review", self.team)

    def test_portable_inputs_rebuild_missing_cache_without_losing_labels(self):
        session = self.prepared()
        session.put_event(1, 10, 8)
        session.save()
        moved = self.root / "moved"
        moved.mkdir()
        for p in (self.video, self.annotation): shutil.copy2(p, moved / p.name)
        (session.frames_dir / "000001.png").unlink()
        with patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()):
            restored, _ = prepare(moved / self.video.name, moved / self.annotation.name, session.output)
        self.assertEqual(restored.events[0]["x"], 10)
        self.assertTrue((restored.frames_dir / "000001.png").exists())
        self.assertEqual(restored.state["inputs"]["video"], str((moved / self.video.name).resolve()))
        restored.save()
        (moved / self.video.name).write_bytes(b"different-video")
        saved = (session.output / "session.json").read_bytes()
        with self.assertRaises(ValueError): prepare(moved / self.video.name, moved / self.annotation.name, session.output)
        self.assertEqual(saved, (session.output / "session.json").read_bytes())

    def test_failed_cache_rebuild_preserves_old_cache_and_labels(self):
        session = self.prepared()
        session.put_event(1, 10, 8)
        session.save()
        before = (session.output / "session.json").read_bytes()
        frame = (session.frames_dir / "000000.png").read_bytes()
        with patch("annotation_core.cv2.VideoCapture", return_value=Capture(2)):
            with self.assertRaises(ValueError): prepare(self.video, self.annotation, session.output, rebuild_cache=True)
        self.assertEqual(before, (session.output / "session.json").read_bytes())
        self.assertEqual(frame, (session.frames_dir / "000000.png").read_bytes())

    def test_shared_cache_decodes_once_for_independent_workspaces(self):
        cache = self.root / "shared"
        with patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()) as capture:
            first, _ = prepare(self.video, self.annotation, self.root / "a", frames_dir=cache)
            second, _ = prepare(self.video, self.annotation, self.root / "b", frames_dir=cache)
        self.assertEqual(capture.call_count, 1)
        first.put_event(1, 10, 8)
        self.assertEqual(second.events, [])
        self.assertEqual(first.frames_dir, second.frames_dir)

    def test_interference_optional_coordinates_update_delete_and_restore(self):
        session = self.prepared()
        record = session.put_non_table(1, "net_contact", reason="球碰到网")
        session.put_non_table(1, "net_contact", 10, 8, "补可见球心")
        self.assertEqual(len(session.state["non_table"]), 1)
        with self.assertRaises(ValueError): session.put_non_table(1, "floor_contact", 32, 0, "坐标错")
        with self.assertRaises(ValueError): session.put_non_table(1, "floor_contact", reason=" ")
        session.save()
        restored = Session(session.output, read_json(session.output / "session.json"))
        self.assertEqual(restored.state["non_table"][0]["x"], 10)
        restored.delete(record["event_id"])
        self.assertEqual(restored.state["non_table"], [])

    def test_viewer_interference_and_no_v_completion(self):
        session = self.prepared()
        viewer = Viewer(session, {"frames": []})
        viewer.handle_key(ord("2"))
        with patch.object(viewer, "dialog", return_value="接触网"):
            viewer.handle_key(13)
        self.assertEqual(session.state["non_table"][0]["event_type"], "net_contact")
        self.assertIsNone(session.state["non_table"][0]["x"])
        for i in range(3):
            viewer.load_frame(i)
            viewer.render()
            session.mark_seen()
        with patch.object(viewer, "confirm", return_value=True), patch.object(viewer, "dialog", return_value="只有触网"):
            viewer.handle_key(ord("c"))
        self.assertIsNotNone(session.progress["completed_at"])
        self.assertNotEqual(len(session.progress["reviewed_frames"]), 3)

    def test_unsaved_draft_blocks_finish_and_can_be_cleared(self):
        session = self.prepared()
        session.put_event(1, 10, 8)
        for i in range(3):
            session.set_frame(i)
            session.mark_seen()
        viewer = Viewer(session, {"frames": []})
        viewer.pending = (10, 8)
        with patch.object(viewer, "confirm", return_value=True):
            viewer.handle_key(ord("c"))
        self.assertIsNone(session.progress["completed_at"])
        viewer.range_start = 1
        viewer.handle_key(ord("k"))
        self.assertIsNone(viewer.pending)
        self.assertIsNone(viewer.range_start)
        self.assertEqual(len(session.events), 1)
        with patch.object(viewer, "confirm", return_value=True):
            viewer.handle_key(ord("c"))
        self.assertIsNotNone(session.progress["completed_at"])

    def test_mismatched_task_id_does_not_create_workspace(self):
        bad = dict(self.task, video_id="wrong")
        with patch("team_annotation.PROJECT", self.root):
            with self.assertRaises(ValueError): prepare_task(bad, "A", "initial", self.team)
        self.assertFalse((self.team / "A/wrong/session.json").exists())

    def test_next_task_loop_opens_only_assigned_independent_workspaces(self):
        from team_annotation import launch
        from unittest.mock import Mock
        second_annotation = self.root / "second.json"
        second_data = read_json(self.annotation)
        second_data["video_id"] = "second"
        write_json(second_annotation, second_data)
        second = dict(self.task, video_id="second", annotation="second.json")
        with patch("team_annotation.PROJECT", self.root), patch("annotation_core.cv2.VideoCapture", side_effect=lambda _: Capture()), \
                patch("cv2.namedWindow"), patch("cv2.destroyWindow"), patch("cv2.destroyAllWindows"), \
                patch("cv2.setMouseCallback"), patch("cv2.imshow"), patch("cv2.getWindowProperty", return_value=1), \
                patch("cv2.waitKeyEx", side_effect=[13, ord("q")]), patch.object(Viewer, "run", side_effect=["next", "tasks"]) as run:
            launch([self.task, second], self.team)
        self.assertEqual(run.call_count, 2)
        self.assertTrue((self.team / "A/clip/session.json").exists())
        self.assertTrue((self.team / "A/second/session.json").exists())
        self.assertFalse((self.team / "B").exists())
        self.assertIsNone(read_json(self.team / "A/clip/session.json")["rounds"]["initial"]["completed_at"])

    def test_legacy_migration_preserves_events_and_frozen_state(self):
        session = self.prepared()
        session.put_event(1, 10, 8)
        self.finish(session)
        old = read_json(session.output / "session.json")
        old["schema_version"] = 1
        old["rounds"].pop("review")
        old["events"].pop("review")
        old.pop("non_table")
        old.pop("participants")
        write_json(session.output / "session.json", old)
        (session.output / "non_table_events.jsonl").write_text(json.dumps({"event_id": "legacy_net", "video_id": "clip",
                   "frame_id": 2, "event_type": "net_contact", "review_state": "user_confirmed", "source": "user"}) + "\n", encoding="utf-8")
        restored, _ = prepare(self.video, self.annotation, session.output)
        restored.save()
        self.assertEqual(restored.events, old["events"]["initial"])
        self.assertEqual(restored.state["non_table"][0]["source"], "user")
        self.assertTrue((session.output / "session.legacy-backup.json").exists())
        with self.assertRaises(ValueError): restored.put_event(1, 20, 8)
        restored.reopen("修正")
        self.assertEqual(len(list((restored.output / "history").glob("*.json"))), 1)
        restored.put_event(1, 20, 8)

    def test_task_allocation_counts_and_relative_paths(self):
        data = self.root / "training"
        (data / "annotations").mkdir(parents=True)
        (data / "rallies_videos").mkdir()
        for i in range(154):
            name = "03_007" if i == 0 else f"clip_{i:03}"
            (data / "rallies_videos" / f"{name}.mp4").write_bytes(b"video")
            write_json(data / "annotations" / f"{name}.json", {"video_id": name,
                       "video_path": f"rallies_videos/{name}.mp4", "num_frames": 10+i})
        with patch("team_annotation.PROJECT", self.root):
            path = self.root / "tasks.json"
            tasks = generate_tasks(path, data)
            self.assertEqual(len(load_tasks(path)), 154)
            self.assertEqual([sum(t["annotator"] == m for t in tasks) for m in "ABCD"], [39, 39, 38, 38])
            self.assertEqual(next(t for t in tasks if t["video_id"] == "03_007")["annotator"], "A")
            self.assertTrue(all(not Path(t["video"]).is_absolute() and t["annotator"] != t["reviewer"] for t in tasks))
            with self.assertRaises(ValueError): generate_tasks(path, data)


if __name__ == "__main__":
    unittest.main()
