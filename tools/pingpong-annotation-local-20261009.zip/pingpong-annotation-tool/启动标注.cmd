@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0development\annotation\Start-Annotation.ps1"
