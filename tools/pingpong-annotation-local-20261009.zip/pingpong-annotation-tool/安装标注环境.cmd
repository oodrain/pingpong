@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0development\annotation\Setup-Annotation.ps1"
pause
